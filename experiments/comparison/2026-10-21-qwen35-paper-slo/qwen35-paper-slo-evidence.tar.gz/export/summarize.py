import json, math, statistics
from pathlib import Path
root=Path('/data/tiankuan/huzhengyu/qwen35-paper-slo-20261021')
groups={
 'xllm_overlap_graph_off':[f'xllm-overlap-valid-c16-r{i}' for i in (1,2,3)],
 'xllm_overlap_off_graph_off':[f'xllm-overlap-off-valid-c16-r{i}' for i in (1,2,3)],
 'xllm_overlap_graph_on':[f'xllm-graph-on-valid-c16-r{i}' for i in (1,2,3)],
 'vllm_rc2_graph_async':['vllm-rc2-graph-async-c16','vllm-rc2-graph-async-c16-r2','vllm-rc2-graph-async-c16-r3'],
}
def pct(vals,q):
 vals=sorted(vals); pos=(len(vals)-1)*q; lo=int(pos); hi=math.ceil(pos)
 return vals[lo] if lo==hi else vals[lo]*(hi-pos)+vals[hi]*(pos-lo)
out={'schema_version':1,'workload':{'model':'Qwen3.5-4B BF16','input_tokens_observed':'2033-2034','output_tokens':2048,'requests':48,'concurrency':16,'request_rate':0,'npu':'Ascend 910C 64GB physical device 0','host':'bm-jn-zs-zone1-910C-64G-10-171','prefix_cache':False},'groups':{}}
for g,names in groups.items():
 rows=[]
 for name in names:
  s=json.load(open(root/'results'/name/'summary.json'))
  details=[json.loads(x) for x in open(root/'results'/name/'details.jsonl')]
  ok=[d for d in details if d['success']]
  row={'run':name,'throughput_tps':s['output_throughput_tps'],'ttft_p90_s':s['ttft_p90_s'],'ttft_p99_s':pct([d['ttft_s'] for d in ok],.99),'tpot_mean_ms':s['tpot_mean_ms'],'tpot_p90_ms':s['tpot_p90_ms'],'tpot_p99_ms':pct([d['tpot_ms'] for d in ok],.99),'successes':s['successes'],'wall_s':s['wall_s'],'output_hashes':sorted({d['output_sha256'] for d in ok})}
  rows.append(row)
 keys=['throughput_tps','ttft_p90_s','ttft_p99_s','tpot_mean_ms','tpot_p90_ms','tpot_p99_ms']
 out['groups'][g]={'runs':rows,'mean':{k:statistics.mean(r[k] for r in rows) for k in keys},'stdev':{k:statistics.stdev(r[k] for r in rows) for k in keys}}
base=out['groups']['vllm_rc2_graph_async']['mean']
best=out['groups']['xllm_overlap_graph_off']['mean']
off=out['groups']['xllm_overlap_off_graph_off']['mean']
graph=out['groups']['xllm_overlap_graph_on']['mean']
out['deltas']={
 'xllm_vs_vllm':{'throughput_pct':(best['throughput_tps']/base['throughput_tps']-1)*100,'ttft_p90_pct':(best['ttft_p90_s']/base['ttft_p90_s']-1)*100,'ttft_p99_pct':(best['ttft_p99_s']/base['ttft_p99_s']-1)*100,'tpot_mean_pct':(best['tpot_mean_ms']/base['tpot_mean_ms']-1)*100,'tpot_p99_pct':(best['tpot_p99_ms']/base['tpot_p99_ms']-1)*100},
 'xllm_overlap_on_vs_off':{'throughput_pct':(best['throughput_tps']/off['throughput_tps']-1)*100,'ttft_p90_pct':(best['ttft_p90_s']/off['ttft_p90_s']-1)*100,'tpot_mean_pct':(best['tpot_mean_ms']/off['tpot_mean_ms']-1)*100},
 'xllm_graph_on_vs_off_with_overlap':{'throughput_pct':(graph['throughput_tps']/best['throughput_tps']-1)*100,'ttft_p90_pct':(graph['ttft_p90_s']/best['ttft_p90_s']-1)*100,'tpot_mean_pct':(graph['tpot_mean_ms']/best['tpot_mean_ms']-1)*100},
}
(root/'comparison-summary.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out['deltas'],indent=2))
