# Excluded runs

Two directories named `graph-off-overlap-on-c16-r2/r3` outside this export were excluded. During those requests the bastion rejected `docker stop`, so the vLLM process still owned port 18080; process and NPU evidence proved the requests hit vLLM rather than xLLM. They are not used in any aggregate. The valid export requires both an xLLM process command line and the server `Master init options` log before measurement.
