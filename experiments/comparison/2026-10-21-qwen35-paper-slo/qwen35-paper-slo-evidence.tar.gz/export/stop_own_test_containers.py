import json, subprocess, sys
names=['vllm-qwen35-hzy-171-20261021','xllm-qwen35-hzy-171-20261021','xllm-qwen35-hzy-171-20261021b']
allowed={'hzy-vllm-qwen35','hzy-xllm-qwen35'}
for name in names:
    p=subprocess.run(['docker','inspect',name,'--format','{{json .Config.Labels}}'],text=True,capture_output=True)
    if p.returncode: continue
    labels=json.loads(p.stdout)
    if labels.get('project') not in allowed:
        raise SystemExit(f'refuse {name}: {labels}')
    print('stopping',name,labels['project'],flush=True)
    subprocess.run(['docker','stop','-t','30',name],check=False)
