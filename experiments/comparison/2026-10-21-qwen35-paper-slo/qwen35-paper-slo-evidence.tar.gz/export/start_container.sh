#!/usr/bin/env bash
set -euo pipefail
work=/data/tiankuan/huzhengyu/qwen35-paper-slo-20261021
source_root=/data/tiankuan/huzhengyu/xllm-glm53-20261020/sources/xllm
runtime_root=/data/tiankuan/huzhengyu/xllm-glm53-20261020/runtime-root
model=/public-flash/tiankuan/czh1/models/models/qwen--Qwen3.5-4B/snapshots/master
image=quay.io/jd_xllm/xllm-ai:xllm-dev-a3-arm-cann9-20260911
container=xllm-qwen35-hzy-171-20261021
if docker container inspect "$container" >/dev/null 2>&1; then
  test "$(docker inspect "$container" --format '{{index .Config.Labels "project"}}')" = hzy-xllm-qwen35
  docker start "$container"
  exit 0
fi
devices=(--device /dev/davinci0:/dev/davinci0)
for path in /dev/davinci_manager /dev/devmm_svm /dev/hisi_hdc /dev/infiniband/rdma_cm /dev/infiniband/umad0 /dev/infiniband/umad1 /dev/infiniband/uverbs0 /dev/infiniband/uverbs1; do
  [[ -e "$path" ]] && devices+=(--device "$path:$path")
done
binds=(
  -v /usr/local/Ascend/driver:/usr/local/Ascend/driver:ro
  -v /usr/local/dcmi:/usr/local/dcmi:ro
  -v /usr/local/sbin/npu-smi:/usr/local/sbin/npu-smi:ro
  -v /etc/hccn.conf:/etc/hccn.conf:ro
  -v "$model:/models/Qwen3.5-4B:ro"
  -v "$source_root:/work/xllm:rw"
  -v "$work:/bench:rw"
  -v "$runtime_root/usr/local/Ascend/cann-9.0.0/opp/vendors/custom_xllm_math:/usr/local/Ascend/cann-9.0.0/opp/vendors/custom_xllm_math:ro"
  -v "$runtime_root/usr/local/python3.11.15/lib/python3.11/site-packages/xlite:/usr/local/python3.11.15/lib/python3.11/site-packages/xlite:ro"
  -v "$runtime_root/usr/local/python3.11.15/lib/python3.11/site-packages/xlite-0.0.0.dist-info:/usr/local/python3.11.15/lib/python3.11/site-packages/xlite-0.0.0.dist-info:ro"
)
[[ -d /usr/local/Ascend/add-ons ]] && binds+=(-v /usr/local/Ascend/add-ons:/usr/local/Ascend/add-ons:ro)
docker run -d --name "$container" --label project=hzy-xllm-qwen35 \
  --network host --shm-size 64g --security-opt seccomp=unconfined --ulimit memlock=-1:-1 \
  "${devices[@]}" "${binds[@]}" \
  -e PIP_NO_INDEX=1 -e HF_HUB_OFFLINE=1 -e TRANSFORMERS_OFFLINE=1 \
  -e TORCH_DEVICE_BACKEND_AUTOLOAD=0 -e PYTORCH_NPU_ALLOC_CONF=expandable_segments:True \
  -e ATB_MATMUL_SHUFFLE_K_ENABLE=1 -e ATB_WORKSPACE_MEM_ALLOC_GLOBAL=1 \
  -e ATB_OPSRUNNER_KERNEL_CACHE_GLOBAL_COUNT=16 \
  "$image" bash -lc 'sleep infinity'
