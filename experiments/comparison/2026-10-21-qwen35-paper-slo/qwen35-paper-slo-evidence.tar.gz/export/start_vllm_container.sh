#!/usr/bin/env bash
set -euo pipefail
work=/data/tiankuan/huzhengyu/qwen35-paper-slo-20261021
model=/public-flash/tiankuan/czh1/models/models/qwen--Qwen3.5-4B/snapshots/master
image=quay.io/ascend/vllm-ascend:v0.30.0rc2-a3
container=vllm-qwen35-hzy-171-20261021
if docker container inspect "$container" >/dev/null 2>&1; then
  test "$(docker inspect "$container" --format '{{index .Config.Labels "project"}}')" = hzy-vllm-qwen35
  docker start "$container"
  exit 0
fi
devices=(--device /dev/davinci0:/dev/davinci0)
for path in /dev/davinci_manager /dev/devmm_svm /dev/hisi_hdc /dev/infiniband/rdma_cm /dev/infiniband/umad0 /dev/infiniband/umad1 /dev/infiniband/uverbs0 /dev/infiniband/uverbs1; do
  [[ -e "$path" ]] && devices+=(--device "$path:$path")
done
docker run -d --name "$container" --label project=hzy-vllm-qwen35 \
  --runtime ascend --network host --shm-size 64g --security-opt seccomp=unconfined \
  --ulimit memlock=-1:-1 --cap-add IPC_LOCK \
  "${devices[@]}" \
  -v /usr/local/Ascend/driver:/usr/local/Ascend/driver:ro \
  -v /usr/local/dcmi:/usr/local/dcmi:ro \
  -v /usr/local/sbin/npu-smi:/usr/local/sbin/npu-smi:ro \
  -v /etc/hccn.conf:/etc/hccn.conf:ro \
  -v "$model:/models/Qwen3.5-4B:ro" -v "$work:/bench:rw" \
  -e HF_HUB_OFFLINE=1 -e TRANSFORMERS_OFFLINE=1 \
  -e PYTORCH_NPU_ALLOC_CONF=expandable_segments:True \
  "$image" bash -lc 'sleep infinity'
