#!/usr/bin/env bash
set -euo pipefail

name=sglang-qwen35-hzy-171-20261021
owner=$(docker inspect -f '{{index .Config.Labels "hzy.codex.owner"}}' "$name")
test "$owner" = inference-framework

docker exec "$name" bash -lc '
set -e
if [ -f /bench/server.pid ]; then
  kill -TERM "$(cat /bench/server.pid)" 2>/dev/null || true
fi
sleep 5
pkill -TERM -f "^python3 -m sglang.launch_server" 2>/dev/null || true
sleep 5
nohup python3 -m sglang.launch_server \
  --model-path /models/Qwen3.5-4B \
  --served-model-name qwen35-4b \
  --host 0.0.0.0 --port 18080 --device npu --tp-size 1 \
  --mem-fraction-static 0.90 --max-running-requests 16 \
  --chunked-prefill-size 8192 --max-prefill-tokens 8192 \
  --disable-radix-cache --disable-overlap-schedule \
  --attention-backend ascend --mamba-ssm-dtype bfloat16 \
  --cuda-graph-backend-prefill disabled \
  --cuda-graph-backend-decode full \
  --cuda-graph-max-bs-decode 16 \
  > /bench/logs/server-bf16-overlap-off.log 2>&1 &
echo $! > /bench/server-overlap-off.pid
'

for _ in $(seq 1 90); do
  if curl -fsS http://127.0.0.1:18080/v1/models >/dev/null 2>&1; then
    echo SERVER_READY
    exit 0
  fi
  sleep 2
done

echo SERVER_NOT_READY
tail -n 80 /data/tiankuan/huzhengyu/qwen35-sglang-20261021/logs/server-bf16-overlap-off.log
exit 1
