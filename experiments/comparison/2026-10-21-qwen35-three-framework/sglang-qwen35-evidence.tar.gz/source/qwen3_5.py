# Copyright 2025 Qwen Team
# Copyright 2025 SGLang Team
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ==============================================================================
"""Inference-only Qwen3.5 model and Qwen3.5 MoE model compatible with HuggingFace weights."""

import logging
import os
from functools import lru_cache
from typing import Iterable, Optional, Set, Tuple, Union

import torch
import torch.nn as nn
import triton
from safetensors.torch import load_file
from transformers.utils import cached_file

from sglang.kernels.ops.attention.fla.layernorm_gated import RMSNorm as RMSNormGated
from sglang.kernels.ops.attention.fla.layernorm_gated import _layer_norm_fwd
from sglang.kernels.ops.attention.triton_gdn_fused_proj import (
    fused_qkvzba_split_reshape_cat_contiguous,
    qwen3_5_gdn_prefill_projection_views,
)
from sglang.kernels.ops.elementwise.elementwise import fused_sigmoid_mul

# Configs
from sglang.srt.configs.model_config import (
    load_decision_config,
    load_joint_head_config,
)
from sglang.srt.configs.qwen3_5 import (
    Qwen3_5Config,
    Qwen3_5MoeConfig,
    Qwen3_5TextConfig,
)

# Distributed
from sglang.srt.distributed import get_pp_indices
from sglang.srt.environ import envs
from sglang.srt.eplb.expert_distribution import get_global_expert_distribution_recorder
from sglang.srt.eplb.expert_location import ModelConfigForExpertLocation
from sglang.srt.layers.attention.mamba.mamba import mamba_v2_sharded_weight_loader
from sglang.srt.layers.aux_hidden_states import (
    AuxHiddenStateAccumulator,
    AuxHiddenStateList,
)
from sglang.srt.layers.dp_attention import (
    is_dp_attention_enabled,
)
from sglang.srt.layers.flashinfer_comm_fusion import uses_cutedsl_ar_fusion
from sglang.srt.layers.joint_schema_head import JointSchemaHead, JointSchemaPooler
from sglang.srt.layers.layer_boundary import (
    append_stages,
    declare_attn,
    declare_ffn,
)

# Layers - Attention
from sglang.srt.layers.layer_boundary.residual import batch as residual_batch

# Layers - Others
from sglang.srt.layers.layer_boundary.residual.add_norm import (
    NORM_QUANT_READOUT,
    Fp8Input,
    NormQuantReadout,
)
from sglang.srt.layers.layernorm import GemmaRMSNorm

# Layers - Linear
from sglang.srt.layers.linear import (
    ColumnParallelLinear,
    LinearParallelGroup,
    MergedColumnParallelLinear,
    QKVParallelLinear,
    ReplicatedParallelGroup,
    RowParallelLinear,
    resolve_linear_parallel_group,
)
from sglang.srt.layers.moe.fused_moe_triton.layer import FusedMoE
from sglang.srt.layers.moe.utils import (
    is_shared_experts_fusion_disabled,
)
from sglang.srt.layers.parameter import (
    BlockQuantScaleParameter,
    PerTensorScaleParameter,
)
from sglang.srt.layers.quantization.base_config import QuantizationConfig
from sglang.srt.layers.quantization.unquant import (
    UnquantizedLinearMethod,
    bf16_gemm_dispatch,
)
from sglang.srt.layers.radix_attention import AttentionType, RadixAttention
from sglang.srt.layers.radix_linear_attention import RadixLinearAttention
from sglang.srt.layers.rotary_embedding import get_rope
from sglang.srt.layers.utils import PPMissingLayer, get_layer_id
from sglang.srt.layers.vocab_parallel_embedding import VocabParallelEmbedding
from sglang.srt.model_executor.cuda_graph_config import (
    Backend,
    Phase,
    check_cuda_graph_backend,
)
from sglang.srt.model_executor.forward_batch_info import ForwardBatch, PPProxyTensors
from sglang.srt.model_executor.runner import get_is_capture_mode
from sglang.srt.model_loader.weight_utils import (
    default_weight_loader,
    sharded_weight_loader,
)
from sglang.srt.models.qwen2_moe import (
    Qwen2MoeMLP,
    Qwen2MoeSparseMoeBlock,
    can_fuse_shared_expert,
)

# Models
from sglang.srt.models.qwen3_vl import Qwen3VLForConditionalGeneration
from sglang.srt.models.utils import (
    WeightsMapper,
    fused_qk_gemma_rmsnorm,
    fused_qk_gemma_rmsnorm_with_gate,
)
from sglang.srt.runtime_context import (
    get_exec,
    get_forward,
    get_lora,
    get_model,
    get_parallel,
    get_stream,
    linear_attn_parallel_group,
)

# Utils
from sglang.srt.utils import (
    LazyValue,
    add_prefix,
    cpu_has_amx_support,
    get_bool_env_var,
    is_cpu,
    is_cuda,
    is_gfx95_supported,
    is_hip,
    is_npu,
    is_xpu,
    make_pp_layers,
    set_weight_attrs,
    use_intel_amx_backend,
)
from sglang.srt.utils.hf_transformers_utils import get_processor, get_rope_config

logger = logging.getLogger(__name__)
_is_cuda = is_cuda()
_is_npu = is_npu()
_is_cpu = is_cpu()
_is_gfx95 = is_gfx95_supported()
_is_hip = is_hip()
_QWEN3_5_MOE_TEXT_MODEL_TYPES = ("qwen3_5_moe_text", "qwen4_exp_text")
# qwen4_exp shares these classes, but the ROCm packed path is Qwen3.5-only.
_QWEN3_5_ROCM_PACKED_MODEL_TYPES = ("qwen3_5_text", "qwen3_5_moe_text")
_is_xpu = is_xpu()
_use_aiter = get_bool_env_var("SGLANG_USE_AITER") and _is_hip
if _use_aiter:
    from aiter.tuned_gemm import tgemm

    from sglang.kernels.ops.gemm.smallm_fp8_gfx950 import (
        smallm_fp8_gemm_config,
        smallm_fp8_gemm_enabled,
    )
_hip_use_alt_stream = get_bool_env_var("SGLANG_ALT_STREAM") and _is_hip
_gdn_use_alt_stream = _is_cuda or (
    get_bool_env_var("SGLANG_GDN_QKVZ_BA_ALT_STREAM", "False") and _hip_use_alt_stream
)
_qknorm_use_alt_stream = _is_cuda or (
    get_bool_env_var("SGLANG_QK_NORM_ALT_STREAM", "False") and _hip_use_alt_stream
)
_gdn_decode_fused_proj_conv = (
    _is_cuda and envs.SGLANG_ENABLE_GDN_DECODE_FUSED_PROJ_CONV.get()
)
_is_amx_available = cpu_has_amx_support()
_is_xpu = is_xpu()

# Head-group ratios (num_v_heads // num_k_heads) served by the fused
# split/reshape/cat Triton kernel. On AMD/aiter the ratio-8 layout is also
# covered by the fused kernel, which removes the two `.contiguous()` copies
# plus the `torch.cat` of the unfused fallback. On CUDA the ratio-3 dense 27B
# layout is handled by the Triton kernel's per-head walk (the CPU fused op
# still requires a power-of-two group). Other backends keep the original
# tuple so their control flow is unchanged.
_GDN_FUSED_QKVZBA_RATIOS = (
    (1, 2, 4, 8) if _use_aiter else (1, 2, 3, 4) if _is_cuda else (1, 2, 4)
)

cached_get_processor = lru_cache(get_processor)


def _disable_shared_experts_fusion() -> bool:
    # Resolved lazily: the flag is written by the owning model's gate before
    # its layers build (per runner); models without a gate see the config
    # intent through the accessor's fallback.
    # The deferred-finalize ABI needs the shared expert as a separate, gated
    # local contribution; it cannot consume a shared slot fused into routed MoE.
    return bool(uses_cutedsl_ar_fusion() or is_shared_experts_fusion_disabled())


def _maybe_enable_silu_fp4_quant_fusion(mlp: nn.Module) -> None:
    """Fuse SiLU+mul with the down_proj NVFP4 input quantization.

    Replaces the separate act_and_mul and per-token FP4 quantize kernels with
    one FlashInfer kernel and feeds down_proj a prequantized (fp4, scale)
    tuple. Enabled when both dense-MLP projections use the NVFP4 (W4A4)
    linear method; kill switch: SGLANG_DISABLE_SILU_FP4_QUANT_FUSION=1.
    """
    if os.environ.get("SGLANG_DISABLE_SILU_FP4_QUANT_FUSION", "0") == "1":
        return
    from sglang.srt.layers.quantization.modelopt_quant import ModelOptFp4LinearMethod

    if not (
        isinstance(mlp.gate_up_proj.quant_method, ModelOptFp4LinearMethod)
        and mlp.gate_up_proj.quant_method.quant_mode == "w4a4"
        and isinstance(mlp.down_proj.quant_method, ModelOptFp4LinearMethod)
    ):
        return
    try:
        from flashinfer import silu_and_mul_scaled_nvfp4_experts_quantize  # noqa: F401
    except ImportError:
        return
    mlp._enable_silu_fp4_quant_fusion = True
    mlp.down_proj._accepts_prequantized_fp4 = True
    logger.info("Enabled fused SiLU+mul+FP4-quant for dense MLP down_proj input.")


def _use_mnnvl_cutedsl_fusion(config: Qwen3_5TextConfig, is_nextn: bool) -> bool:
    return bool(
        not is_nextn
        and config.model_type == "qwen3_5_moe_text"
        and uses_cutedsl_ar_fusion()
    )


def _layer_fusions(config: Qwen3_5TextConfig, is_nextn: bool):
    """The CuTe DSL kernels a layer tries before its own, when they are on."""
    if _use_mnnvl_cutedsl_fusion(config, is_nextn):
        from sglang.srt.layers.layer_boundary.fusions.cutedsl import CuteDSLFusion

        return CuteDSLFusion()
    return None


def _qwen3_5_is_moe(config: Qwen3_5TextConfig) -> bool:
    """Whether the model's layers run sparse MoE blocks rather than dense MLPs:
    every layer of either kind alike."""
    return config.model_type in _QWEN3_5_MOE_TEXT_MODEL_TYPES


def _qwen3_5_stage_facts(
    config: Qwen3_5TextConfig, layer_id: int, *, attn_read=NORM_QUANT_READOUT
):
    """The attention and FFN stages a Qwen3.5 layer of either kind declares:
    the model's shared declaration function (see make_layers), which the
    layer declares itself with. ``attn_read`` is the layer's own attention
    read, which declares what the plain one does and also hands on the
    quantized input its projection takes."""
    sparse = _qwen3_5_is_moe(config)
    return (
        declare_attn(read=attn_read),
        declare_ffn(sparse=sparse, next_layer_sparse=sparse),
    )


if _is_cuda:
    from sglang.kernels.ops.attention.fused_qk_rmsnorm_rope_gate import (
        fused_qk_gemma_rmsnorm_rope_gate,
    )

if _is_cpu:
    _fused_sigmoid_mul_cpu = torch.ops.sgl_kernel.fused_sigmoid_mul_cpu

    def fused_sigmoid_mul(x, gate, inplace=True):
        if not inplace:
            x = x.clone()
        _fused_sigmoid_mul_cpu(x, gate)
        return x

    fused_qk_gemma_rmsnorm = torch.ops.sgl_kernel.fused_qk_gemma_rmsnorm_cpu
    fused_qk_gemma_rmsnorm_with_gate = (
        torch.ops.sgl_kernel.fused_qk_gemma_rmsnorm_with_gate_cpu
    )
    fused_qkvzba_split_reshape_cat_contiguous = (
        torch.ops.sgl_kernel.fused_qkvzba_split_reshape_cat_contiguous_cpu
    )

if _is_npu:
    from sgl_kernel_npu.activation.fused_sigmoid_mul import (
        fused_sigmoid_mul as npu_fused_sigmoid_mul,
    )

    # NPU uses the Ascend-tuned implementation; other backends keep the
    # original Triton kernel.
    from sgl_kernel_npu.fla.utils import fused_qkvzba_split_reshape_cat_contiguous


def _linear_accepts_fp8_tuple(linear: nn.Module) -> bool:
    quant_method = getattr(linear, "quant_method", None)
    return quant_method.__class__.__name__ == "Fp8LinearMethod" and (
        getattr(quant_method, "block_quant", False)
        or getattr(quant_method, "use_mxfp8", False)
    )


def _fp8_tuple_input(linear: nn.Module, num_tokens: int) -> bool:
    """Whether the producer hands ``linear`` a per-token FP8 (q, scale) pair (SGLANG_ROCM_SMALLM_FP8_PROJ)."""
    scheme = getattr(linear, "scheme", None)
    return (
        _use_aiter
        and num_tokens > 0
        and type(scheme).__name__ == "QuarkW8A8Fp8"
        and scheme.per_token
        and scheme.weight_qscheme == "per_channel"
        and smallm_fp8_gemm_config(num_tokens, *linear.weight.shape[::-1]) is not None
        and not torch.compiler.is_compiling()
        and not get_forward().sp_active
        and smallm_fp8_gemm_enabled()
    )


def _select_fused_ar_input_for_linear(hidden_states, linear: nn.Module):
    if not isinstance(hidden_states, tuple):
        return hidden_states
    if len(hidden_states) == 3:
        hs_bf16, hs_fp8, hs_scale = hidden_states
        if _linear_accepts_fp8_tuple(linear):
            return (hs_fp8, hs_scale)
        return hs_bf16
    if len(hidden_states) == 2 and _linear_accepts_fp8_tuple(linear):
        return hidden_states
    raise TypeError(
        f"{linear.__class__.__name__} cannot consume fused AR quant tuple input"
    )


if _is_npu:
    from sgl_kernel_npu.norm.split_qkv_rmsnorm_rope import (
        split_qkvgate_gemma_rmsnorm_rope,
    )


class Qwen3_5GatedDeltaNet(nn.Module):
    def __init__(
        self,
        config: Qwen3_5TextConfig,
        layer_id: int,
        quant_config: Optional[QuantizationConfig] = None,
        alt_stream: Optional[torch.cuda.Stream] = None,
        prefix: str = "",
    ) -> None:
        super().__init__()
        self.config = config
        parallel_group = linear_attn_parallel_group()
        self.attn_tp_rank, self.attn_tp_size = resolve_linear_parallel_group(
            parallel_group
        )
        self.hidden_size = config.hidden_size
        self.num_v_heads = (
            config.linear_num_value_heads
            if not _is_cpu
            else config.linear_num_value_heads_cpu
        )
        self.num_k_heads = (
            config.linear_num_key_heads
            if not _is_cpu
            else config.linear_num_key_heads_cpu
        )
        self.head_k_dim = config.linear_key_head_dim
        self.head_v_dim = config.linear_value_head_dim
        self.key_dim = self.head_k_dim * self.num_k_heads
        self.value_dim = self.head_v_dim * self.num_v_heads
        self.alt_stream = alt_stream

        self.conv_kernel_size = config.linear_conv_kernel_dim
        self.layer_id = layer_id
        self.activation = config.hidden_act
        self.output_gate_type = config.output_gate_type
        self.layer_norm_epsilon = config.rms_norm_eps

        # Conv1d layer
        self.conv_dim = self.key_dim * 2 + self.value_dim
        self.conv1d = ColumnParallelLinear(
            input_size=self.conv_kernel_size,
            output_size=self.conv_dim,
            bias=False,
            quant_config=None,
            parallel_group=parallel_group,
            prefix=add_prefix("conv1d", prefix),
        )
        self.conv1d.weight.data = self.conv1d.weight.data.unsqueeze(1)

        # projection of the input hidden states
        self.in_proj_qkvz = self.create_qkvz_proj(
            hidden_size=self.hidden_size,
            key_dim=self.key_dim,
            value_dim=self.value_dim,
            quant_config=quant_config,
            prefix=add_prefix("in_proj_qkvz", prefix),
            parallel_group=parallel_group,
        )

        self.in_proj_ba = self.create_ba_proj(
            hidden_size=self.hidden_size,
            num_v_heads=self.num_v_heads,
            quant_config=quant_config,
            prefix=add_prefix("in_proj_ba", prefix),
            parallel_group=parallel_group,
        )

        # Override weight loaders for packed checkpoint format.
        # Important: for FP8, this must cover not only `.weight` but also
        # `weight_scale_inv` / `weight_scale` / `input_scale` if present.
        self._bind_packed_weight_loaders(self.in_proj_qkvz)
        self._bind_packed_weight_loaders(self.in_proj_ba)
        self._fused_in_proj_weight: Optional[torch.Tensor] = None
        self._fused_in_proj_qkvz_width = 0
        self._fused_in_proj_ba_width = 0
        self._fused_in_proj_scale: Optional[torch.Tensor] = None
        self._fused_in_proj_sources = None
        self._derived_weight_cache_error = None
        self._fused_input_proj_cpu_enabled = LazyValue(
            lambda: (
                _is_cpu
                and self.in_proj_qkvz._parameters.get("weight") is not None
                and self.in_proj_ba._parameters.get("weight") is not None
                and self.in_proj_qkvz._parameters["weight"].dtype == torch.bfloat16
                and self.in_proj_ba._parameters["weight"].dtype == torch.bfloat16
                and self.in_proj_qkvz.bias is None
                and self.in_proj_ba.bias is None
                and use_intel_amx_backend(self.in_proj_qkvz)
                and use_intel_amx_backend(self.in_proj_ba)
                and (
                    self.in_proj_qkvz.weight.size(0) % 32 == 0
                    and self.in_proj_ba.weight.size(0) % 32 == 0
                )
            )
        )

        # Conv1d weight loader setup
        query_key_settings = (self.key_dim, 0, False)
        value_settings = (self.value_dim, 0, False)

        self._override_weight_loader(
            self.conv1d.weight,
            mamba_v2_sharded_weight_loader(
                [
                    query_key_settings,
                    query_key_settings,
                    value_settings,
                ],
                self.attn_tp_size,
                self.attn_tp_rank,
            ),
        )

        # State parameters
        self.dt_bias = nn.Parameter(
            torch.ones(self.num_v_heads // self.attn_tp_size),
        )
        self.A_log = nn.Parameter(
            torch.empty(self.num_v_heads // self.attn_tp_size, dtype=torch.float32),
        )

        set_weight_attrs(
            self.A_log,
            {"weight_loader": sharded_weight_loader(0, parallel_group=parallel_group)},
        )
        set_weight_attrs(
            self.dt_bias,
            {"weight_loader": sharded_weight_loader(0, parallel_group=parallel_group)},
        )

        conv_weights = self.conv1d.weight.view(
            self.conv1d.weight.size(0), self.conv1d.weight.size(2)
        )
        self.attn = RadixLinearAttention(
            layer_id=layer_id,
            num_q_heads=self.num_k_heads // self.attn_tp_size,
            num_k_heads=self.num_k_heads // self.attn_tp_size,
            num_v_heads=self.num_v_heads // self.attn_tp_size,
            head_q_dim=self.head_k_dim,
            head_k_dim=self.head_k_dim,
            head_v_dim=self.head_v_dim,
            conv_weights=conv_weights,
            bias=self.conv1d.bias,
            activation=self.activation,
            A_log=self.A_log,
            dt_bias=self.dt_bias,
        )

        self.norm = RMSNormGated(
            self.head_v_dim,
            eps=self.layer_norm_epsilon,
            group_size=None,
            norm_before_gate=True,
            dtype=torch.get_default_dtype(),
            **(
                {"activation": self.output_gate_type}
                if self.output_gate_type is not None
                else {}
            ),
        )

        self.out_proj = RowParallelLinear(
            self.value_dim,
            self.hidden_size,
            bias=False,
            input_is_parallel=True,
            reduce_results=False,
            quant_config=quant_config,
            parallel_group=parallel_group,
            prefix=add_prefix("out_proj", prefix),
        )

    @staticmethod
    def _override_weight_loader(param, loader):
        """Robustly override loader for:
        1) BasevLLMParameter subclasses: real storage is `_weight_loader`
        2) regular Parameters that already have mutable `weight_loader`
        3) regular Parameters without `weight_loader` yet
        """
        if hasattr(param, "_weight_loader"):
            # FP8 / quantized BasevLLMParameter path
            param._weight_loader = loader
            return

        if hasattr(param, "weight_loader"):
            # Regular parameter/tensor that already has a mutable attr.
            # Do NOT call set_weight_attrs here, because it asserts when
            # overwriting an existing attribute.
            param.weight_loader = loader
            return

        # Fresh attribute on a normal tensor/Parameter
        set_weight_attrs(param, {"weight_loader": loader})

    def _bind_packed_weight_loaders(self, module):
        """Bind packed-checkpoint-aware loaders to all relevant params of a merged module."""
        for attr_name in ("weight", "weight_scale_inv", "weight_scale", "input_scale"):
            param = getattr(module, attr_name, None)
            if param is None:
                continue
            original_loader = getattr(param, "weight_loader", None)
            if original_loader is None:
                continue
            wrapped_loader = self._make_packed_weight_loader(module, original_loader)
            self._override_weight_loader(param, wrapped_loader)

    @staticmethod
    def _get_split_sizes_for_param(module, param, loaded_shard_id):
        """Return checkpoint-side split sizes for this param type."""
        if isinstance(param, BlockQuantScaleParameter):
            # Split by output blocks, not raw output sizes.
            block_n, _ = module.quant_method.quant_config.weight_block_size
            block_n = 1 if getattr(param, "format_ue8m0", False) else block_n
            return [
                (module.output_sizes[idx] + block_n - 1) // block_n
                for idx in loaded_shard_id
            ]

        if isinstance(param, PerTensorScaleParameter):
            # One logical scale per logical shard.
            return [1 for _ in loaded_shard_id]

        # Normal weight / non-block quant tensor
        return [module.output_sizes[idx] for idx in loaded_shard_id]

    @classmethod
    def _make_packed_weight_loader(cls, module, original_weight_loader):
        """Wrap the param's original loader so split checkpoints:
          - in_proj_qkv + in_proj_z -> merged in_proj_qkvz
          - in_proj_b + in_proj_a   -> merged in_proj_ba
        can load correctly for both normal and FP8 params.
        """

        def weight_loader(param, loaded_weight, loaded_shard_id=None):
            # Only intercept split-checkpoint tuple shards.
            # int shard_id and None should preserve original behavior.
            if isinstance(loaded_shard_id, tuple):
                split_sizes = cls._get_split_sizes_for_param(
                    module, param, loaded_shard_id
                )

                if loaded_weight.numel() == 1:
                    # Single-element tensor (scalar or [1]):
                    # broadcast to each logical shard.
                    chunks = [loaded_weight.view(-1)] * len(loaded_shard_id)
                else:
                    split_dim = getattr(param, "output_dim", 0)
                    if _is_cpu:
                        cpu_split_sizes = []
                        split_size_sum = sum(split_sizes)
                        target_size_sim = loaded_weight.size(split_dim)
                        for i in range(len(split_sizes)):
                            cpu_split_sizes.append(
                                int(target_size_sim * split_sizes[i] / split_size_sum)
                            )
                        assert sum(cpu_split_sizes) == target_size_sim, (
                            f"Padding the loaded weight failed due to sizes are not divisible cleanly from {cpu_split_sizes} to {target_size_sim}"
                        )
                        chunks = loaded_weight.split(cpu_split_sizes, dim=split_dim)
                    else:
                        chunks = loaded_weight.split(split_sizes, dim=split_dim)

                assert len(chunks) == len(loaded_shard_id), (
                    f"Chunk/shard mismatch: {len(chunks)=}, "
                    f"{len(loaded_shard_id)=}, {split_sizes=}"
                )

                for idx, chunk in zip(loaded_shard_id, chunks):
                    # Delegate each chunk to the param's original int-shard loader.
                    original_weight_loader(param, chunk, idx)
                return

            return original_weight_loader(param, loaded_weight, loaded_shard_id)

        return weight_loader

    def create_qkvz_proj(
        self,
        hidden_size: int,
        key_dim: int,
        value_dim: int,
        quant_config: QuantizationConfig | None,
        prefix: str,
        *,
        parallel_group: LinearParallelGroup = "tp",
    ) -> MergedColumnParallelLinear:
        return MergedColumnParallelLinear(
            input_size=hidden_size,
            output_sizes=[key_dim, key_dim, value_dim, value_dim],
            bias=False,
            quant_config=quant_config,
            prefix=prefix,
            parallel_group=parallel_group,
        )

    def create_ba_proj(
        self,
        hidden_size: int,
        num_v_heads: int,
        quant_config: QuantizationConfig | None,
        prefix: str,
        *,
        parallel_group: LinearParallelGroup = "tp",
    ) -> MergedColumnParallelLinear:
        # Qwen3.5 has separate in_proj_b and in_proj_a weights in the
        # checkpoint, which are loaded into the fused in_proj_ba parameter
        # via stacked_params_mapping with shard_id 0 and 1 respectively.
        return MergedColumnParallelLinear(
            input_size=hidden_size,
            output_sizes=[num_v_heads, num_v_heads],
            bias=False,
            quant_config=quant_config,
            prefix=prefix,
            parallel_group=parallel_group,
        )

    def fix_query_key_value_ordering(
        self,
        mixed_qkvz: torch.Tensor,
        mixed_ba: torch.Tensor,
    ):
        """
        Derives `query`, `key` and `value` tensors from `mixed_qkvzba`.
        """
        k_tp = self.key_dim // self.attn_tp_size
        v_tp = self.value_dim // self.attn_tp_size
        nv_tp = self.num_v_heads // self.attn_tp_size

        # Directly split, no head group reshape
        query, key, value, z = mixed_qkvz.split([k_tp, k_tp, v_tp, v_tp], dim=-1)
        b, a = mixed_ba.split([nv_tp, nv_tp], dim=-1)

        # value / z reshape to (seq, num_v_heads/tp, head_v_dim)
        value = value.reshape(value.size(0), -1, self.head_v_dim)
        z = z.reshape(z.size(0), -1, self.head_v_dim)

        return query, key, value, z, b, a

    def finalize_fused_in_proj(self) -> None:
        """Prepare one BF16 or FP8 GEMM for both input projections.

        BF16 parameters alias the packed rows. FP8 keeps the original layouts
        for the separate path and publishes its derived-cache update constraint.
        """
        if not (_is_cuda or _use_aiter) or self._fused_in_proj_weight is not None:
            return
        if (
            _use_aiter
            and self.config.model_type not in _QWEN3_5_ROCM_PACKED_MODEL_TYPES
        ):
            return
        if get_lora().enable_lora or get_lora().lora_paths:
            # LoRA wraps the individual Linear modules; the fused GEMM would
            # bypass their adapters.
            return
        if _use_aiter and not get_bool_env_var("SGLANG_QWEN35_PACKED_IN_PROJ", "True"):
            return
        qkvz, ba = self.in_proj_qkvz, self.in_proj_ba
        if _use_aiter and self._finalize_fused_fp8_in_proj():
            return
        if not (
            isinstance(qkvz.quant_method, UnquantizedLinearMethod)
            and isinstance(ba.quant_method, UnquantizedLinearMethod)
            and qkvz.weight.dtype == torch.bfloat16
            and ba.weight.dtype == torch.bfloat16
            and qkvz.bias is None
            and ba.bias is None
        ):
            return
        fused = torch.cat([qkvz.weight.data, ba.weight.data], dim=0).contiguous()
        self._fused_in_proj_qkvz_width = qkvz.weight.shape[0]
        qkvz.weight.data = fused[: self._fused_in_proj_qkvz_width]
        ba.weight.data = fused[self._fused_in_proj_qkvz_width :]
        self._fused_in_proj_weight = fused

    def _finalize_fused_fp8_in_proj(self) -> bool:
        """Pack loaded Quark per-channel FP8 projections without requantizing."""
        from aiter.ops.shuffle import shuffle_weight

        from sglang.srt.layers.quantization.fp8_utils import use_aiter_bpreshuffle_gemm
        from sglang.srt.layers.quantization.quark.schemes.quark_w8a8_fp8 import (
            QuarkW8A8Fp8,
        )

        projections = (self.in_proj_qkvz, self.in_proj_ba)
        if not all(
            type(getattr(proj, "scheme", None)) is QuarkW8A8Fp8
            and proj.scheme.weight_qscheme == "per_channel"
            and proj.scheme.per_token
            and proj.input_scale is None
            and proj.bias is None
            and proj.weight.dtype == torch.float8_e4m3fn
            and proj.weight.is_cuda
            and proj.weight.t().is_contiguous()
            and proj.weight.shape[1] % 16 == 0
            and proj.weight_scale.numel() == proj.weight.shape[1]
            for proj in projections
        ):
            return False
        # Keep the derived-cache update constraint uniform across ranks. With
        # PP, an attention-only stage may have no GDN cache to publish it from.
        if get_parallel().pp_size != 1:
            return False
        widths = [proj.weight.shape[1] for proj in projections]
        if projections[0].weight.shape[0] != projections[1].weight.shape[0]:
            return False
        # CK's bpreshuffle GEMM requires N % 64 == 0. TP4 has BA=32,
        # so pad only the packed result, preserving the original Linear sizes.
        padded_width = (sum(widths) + 63) // 64 * 64
        weight = torch.zeros(
            (padded_width, projections[0].weight.shape[0]),
            dtype=projections[0].weight.dtype,
            device=projections[0].weight.device,
        )
        scale = torch.ones((padded_width, 1), dtype=torch.float32, device=weight.device)
        offset = 0
        for proj, width in zip(projections, widths):
            source = proj.weight.t()
            if not use_aiter_bpreshuffle_gemm(width):
                source = shuffle_weight(source, (16, 16))
            # AITER's shuffle is local to 16 output rows; concatenating aligned
            # shuffled blocks is identical to shuffling their concatenation.
            weight[offset : offset + width].copy_(source)
            scale[offset : offset + width].copy_(proj.weight_scale.view(-1, 1))
            offset += width
        self._fused_in_proj_weight = weight
        self._fused_in_proj_scale = scale
        self._fused_in_proj_qkvz_width, self._fused_in_proj_ba_width = widths
        self._fused_in_proj_sources = tuple(
            (value, value.data_ptr(), None if value.is_inference() else value._version)
            for proj in projections
            for value in (proj.weight, proj.weight_scale)
        )
        self._derived_weight_cache_error = (
            "Online weight updates are not supported with packed FP8 GDN input "
            "projections: captured graphs retain a derived weight/scale buffer. "
            "Restart with SGLANG_QWEN35_PACKED_IN_PROJ=0 before updating weights."
        )
        return True

    def _fused_fp8_in_proj_sources_valid(self) -> bool:
        current = tuple(
            value
            for proj in (self.in_proj_qkvz, self.in_proj_ba)
            for value in (proj.weight, proj.weight_scale)
        )
        return all(
            value is source
            and value.data_ptr() == pointer
            and (version is None or value._version == version)
            for value, (source, pointer, version) in zip(
                current, self._fused_in_proj_sources
            )
        )

    def _forward_input_proj(self, hidden_states: torch.Tensor):
        if _use_aiter and self._fused_in_proj_weight is not None:
            # Unquantized BF16 projections consume the bf16 side of the fused
            # AR+RMSNorm tuple; one aiter GEMM replaces the two separate
            # projections. Measured on MI355X the packed GEMM only pays off for
            # decode/verify-sized batches, so larger batches keep the separate
            # projections below.
            x = hidden_states[0] if isinstance(hidden_states, tuple) else hidden_states
            if (
                x.dtype == torch.bfloat16
                and 0 < x.shape[0] <= 64
                and not torch.compiler.is_compiling()
            ):
                if self._fused_in_proj_scale is not None:
                    if self._fused_fp8_in_proj_sources_valid():
                        from sglang.srt.layers.quantization.fp8_utils import (
                            apply_fp8_linear,
                        )

                        fused_out = apply_fp8_linear(
                            x,
                            self._fused_in_proj_weight.t(),
                            self._fused_in_proj_scale,
                            use_per_token_if_dynamic=True,
                        )
                        split = self._fused_in_proj_qkvz_width
                        return (
                            fused_out[:, :split],
                            fused_out[:, split : split + self._fused_in_proj_ba_width],
                        )
                else:
                    fused_out = tgemm.mm(
                        x, self._fused_in_proj_weight, None, otype=x.dtype
                    )
                    return (
                        fused_out[:, : self._fused_in_proj_qkvz_width],
                        fused_out[:, self._fused_in_proj_qkvz_width :],
                    )
        # AMD/aiter fused AR+RMSNorm+per-group-quant path ships a
        # ``(bf16, fp8, scale)`` 3-tuple so the FP8 ``in_proj_qkvz`` can
        # consume ``(fp8, scale)`` (skipping its internal quant) while the
        # bf16 ``in_proj_ba`` consumes the unquantized bf16. Non-aiter runs skip
        # the tuple branch and keep the original control flow below unchanged.
        if _use_aiter and isinstance(hidden_states, tuple):
            return self._forward_input_proj_fused_quant_amd(hidden_states)

        if (
            not _use_aiter
            and self._fused_in_proj_weight is not None
            and hidden_states.dtype == torch.bfloat16
            # Measured on cuBLAS above ~1k rows:
            # the merged (m, 4120) GEMM is ~10% slower than the two separate GEMMs.
            and hidden_states.shape[0] <= 1024
        ):
            fused_out = bf16_gemm_dispatch(
                hidden_states, self._fused_in_proj_weight, None
            )
            return (
                fused_out[:, : self._fused_in_proj_qkvz_width],
                fused_out[:, self._fused_in_proj_qkvz_width :],
            )

        if (
            _is_cpu
            or _is_npu
            or check_cuda_graph_backend(Phase.PREFILL, Backend.TC_PIECEWISE)
        ):
            DUAL_STREAM_TOKEN_THRESHOLD = 0
        else:
            DUAL_STREAM_TOKEN_THRESHOLD = 1024

        seq_len, _ = hidden_states.shape
        if (
            self.alt_stream is not None
            and get_is_capture_mode()
            and seq_len < DUAL_STREAM_TOKEN_THRESHOLD
            and _gdn_use_alt_stream
        ):
            current_stream = torch.cuda.current_stream()
            self.alt_stream.wait_stream(current_stream)
            projected_states_qkvz, _ = self.in_proj_qkvz(hidden_states)
            with torch.cuda.stream(self.alt_stream):
                projected_states_ba, _ = self.in_proj_ba(hidden_states)
            current_stream.wait_stream(self.alt_stream)
        elif self._fused_input_proj_cpu_enabled.value:
            projected_states_qkvz, projected_states_ba = (
                torch.ops.sgl_kernel.fused_input_proj_cpu(
                    hidden_states,
                    self.in_proj_qkvz.weight,
                    self.in_proj_ba.weight,
                    True,
                )
            )
        else:
            projected_states_qkvz, _ = self.in_proj_qkvz(hidden_states)
            projected_states_ba, _ = self.in_proj_ba(hidden_states)
        return projected_states_qkvz, projected_states_ba

    def _forward_input_proj_fused_quant_amd(self, hidden_states):
        """AMD-only variant for the fused AR+RMSNorm+per-group-quant path.

        ``hidden_states`` is a ``(bf16, fp8, scale)`` 3-tuple produced by the
        upstream fused kernel. FP8 ``in_proj_qkvz`` takes ``(fp8, scale)``
        directly; unquantized variants take the bf16 side-output.
        """
        hs_bf16 = hidden_states[0]
        hs_qkvz = _select_fused_ar_input_for_linear(hidden_states, self.in_proj_qkvz)
        seq_len = hs_bf16.shape[0]

        if check_cuda_graph_backend(Phase.PREFILL, Backend.TC_PIECEWISE):
            DUAL_STREAM_TOKEN_THRESHOLD = 0
        else:
            DUAL_STREAM_TOKEN_THRESHOLD = 1024

        if (
            self.alt_stream is not None
            and get_is_capture_mode()
            and seq_len < DUAL_STREAM_TOKEN_THRESHOLD
            and _gdn_use_alt_stream
        ):
            current_stream = torch.cuda.current_stream()
            self.alt_stream.wait_stream(current_stream)
            projected_states_qkvz, _ = self.in_proj_qkvz(hs_qkvz)
            with torch.cuda.stream(self.alt_stream):
                projected_states_ba, _ = self.in_proj_ba(hs_bf16)
            current_stream.wait_stream(self.alt_stream)
        else:
            projected_states_qkvz, _ = self.in_proj_qkvz(hs_qkvz)
            projected_states_ba, _ = self.in_proj_ba(hs_bf16)
        return projected_states_qkvz, projected_states_ba

    def _forward_xpu(
        self,
        backend: object,
        projected_states_qkvz: torch.Tensor,
        projected_states_ba: torch.Tensor,
        forward_batch: ForwardBatch,
    ):
        core_attn_out, z = backend.forward_fused_gdn(
            self.attn,
            forward_batch,
            projected_states_qkvz,
            projected_states_ba,
        )

        assert core_attn_out is not None, "XPU backend must support fused GDN"

        z_shape_og = z.shape
        # reshape input data into 2D tensor
        core_attn_out = core_attn_out.reshape(-1, core_attn_out.shape[-1])
        z = z.reshape(-1, z.shape[-1])

        # Add padding for DP-Attn
        if core_attn_out.shape != z.shape:
            core_attn_out_pad = torch.zeros_like(z)
            core_attn_out_pad[: core_attn_out.shape[0], :] = core_attn_out
            core_attn_out = core_attn_out_pad

        core_attn_out = self.norm(core_attn_out, z)
        core_attn_out = core_attn_out.reshape(z_shape_og)
        core_attn_out = core_attn_out.reshape(*core_attn_out.shape[:-2], -1)

        output, _ = self.out_proj(core_attn_out)
        return output

    def forward(
        self,
        hidden_states: torch.Tensor,
        forward_batch: ForwardBatch,
    ):
        """
        Forward pass with three parts:
        1. Input projection
        2. Core attention (custom op)
        3. Output projection
        """
        projected_states_qkvz, projected_states_ba = self._forward_input_proj(
            hidden_states
        )

        if _is_xpu and get_exec().mamba.linear_attn_backend == "intel_xpu":
            from sglang.srt.model_executor.forward_context import get_attn_backend

            backend = get_attn_backend()
            backend = getattr(backend, "linear_attn_backend", backend)
            if backend.supports_fused_gdn(self.attn, forward_batch):
                return self._forward_xpu(
                    backend, projected_states_qkvz, projected_states_ba, forward_batch
                )

        use_strided_prefill_z = False
        packed_verify = False
        if forward_batch.forward_mode.is_target_verify():
            from sglang.srt.model_executor.forward_context import get_attn_backend

            backend = get_attn_backend()
            backend = getattr(backend, "linear_attn_backend", backend)
            packed_verify = getattr(backend, "supports_packed_verify", False)
        use_fused_proj_conv = (
            _gdn_decode_fused_proj_conv
            and (forward_batch.forward_mode.is_decode() or packed_verify)
            and isinstance(projected_states_qkvz, torch.Tensor)
            and isinstance(projected_states_ba, torch.Tensor)
        )
        use_fused_contiguous_unpack = (
            self.num_v_heads // self.num_k_heads in _GDN_FUSED_QKVZBA_RATIOS
        )
        if use_fused_proj_conv:
            # GDN owns indexed Conv1D state and the safe unpack/Conv boundary;
            # it replaces these temporary B/A placeholders before recurrence.
            mixed_qkv = (projected_states_qkvz, projected_states_ba)
            z = None
            b = projected_states_ba
            a = projected_states_ba
        elif use_fused_contiguous_unpack:
            if _is_cpu:
                num_k_heads_tp = self.num_k_heads // self.attn_tp_size
                num_v_heads_tp = self.num_v_heads // self.attn_tp_size
            else:
                num_k_heads_tp = triton.cdiv(self.num_k_heads, self.attn_tp_size)
                num_v_heads_tp = triton.cdiv(self.num_v_heads, self.attn_tp_size)
            use_strided_prefill_z = (
                _is_cuda and forward_batch.forward_mode.is_extend_without_speculative()
            )
            split_fn = (
                qwen3_5_gdn_prefill_projection_views
                if use_strided_prefill_z
                else fused_qkvzba_split_reshape_cat_contiguous
            )
            mixed_qkv, z, b, a = split_fn(
                projected_states_qkvz,
                projected_states_ba,
                num_k_heads_tp,
                num_v_heads_tp,
                self.head_k_dim,
                self.head_v_dim,
            )
        else:
            query, key, value, z, b, a = self.fix_query_key_value_ordering(
                projected_states_qkvz, projected_states_ba
            )
            b = b.contiguous()
            a = a.contiguous()

            query, key, value = map(
                lambda x: x.reshape(x.shape[0], -1), (query, key, value)
            )
            mixed_qkv = torch.cat((query, key, value), dim=-1)

        attn_result = self.attn(
            forward_batch,
            mixed_qkv=mixed_qkv,
            a=a,
            b=b,
        )
        if use_fused_proj_conv:
            if not isinstance(attn_result, tuple) or len(attn_result) != 2:
                raise RuntimeError(
                    "Fused GDN projection/Conv1D backend must return (core_attn_out, z)"
                )
            core_attn_out, z = attn_result
        else:
            core_attn_out = attn_result
        assert z is not None

        z_shape_og = z.shape
        # reshape input data into 2D tensor
        core_attn_out = core_attn_out.reshape(-1, core_attn_out.shape[-1])
        if use_strided_prefill_z:
            z_flat_shape = (z.numel() // z.shape[-1], z.shape[-1])
        else:
            z = z.reshape(-1, z.shape[-1])
            z_flat_shape = z.shape

        # Add padding for DP-Attn
        if core_attn_out.shape != z_flat_shape:
            core_attn_out_pad = z.new_zeros(z_flat_shape)
            core_attn_out_pad[: core_attn_out.shape[0], :] = core_attn_out
            core_attn_out = core_attn_out_pad

        nv = self.num_v_heads // self.attn_tp_size
        if not use_strided_prefill_z and _fp8_tuple_input(self.out_proj, len(z) // nv):
            fp8, _, _ = _layer_norm_fwd(
                core_attn_out,
                self.norm.weight,
                None,
                self.norm.eps,
                z=z,
                is_rms_norm=True,
                activation=self.norm.activation,
                quant_heads=nv,
            )
            return self.out_proj(fp8)[0]

        core_attn_out = self.norm(core_attn_out, z)
        core_attn_out = core_attn_out.reshape(z_shape_og)
        core_attn_out = core_attn_out.reshape(
            *core_attn_out.shape[:-2],
            core_attn_out.shape[-2] * core_attn_out.shape[-1],
        )

        output, _ = self.out_proj(core_attn_out)
        return output


class Qwen3_5LinearDecoderLayer(nn.Module):
    """Qwen3.5 Decoder Layer with Linear Attention (GatedDeltaNet)."""

    stage_facts = staticmethod(_qwen3_5_stage_facts)

    def __init__(
        self,
        config: Qwen3_5TextConfig,
        layer_id: int,
        quant_config: Optional[QuantizationConfig] = None,
        prefix: str = "",
        alt_stream: Optional[torch.cuda.Stream] = None,
        is_nextn: bool = False,
        build_stages: bool = True,
    ) -> None:
        super().__init__()
        self.config = config
        self.layer_id = layer_id

        self.linear_attn = Qwen3_5GatedDeltaNet(
            config, layer_id, quant_config, alt_stream, prefix
        )

        # NOTE: Determine the MLP type based on the model type
        # Qwen3.5 use all layers for MLP / Qwen3.5-MoE use sparse MoE blocks
        if _qwen3_5_is_moe(config):
            self.mlp = Qwen2MoeSparseMoeBlock(
                layer_id=layer_id,
                config=config,
                quant_config=quant_config,
                alt_stream=(
                    alt_stream
                    if (_is_cuda or _disable_shared_experts_fusion())
                    else None
                ),
                prefix=add_prefix("mlp", prefix.replace(".linear_attn", "")),
                is_nextn=is_nextn,
                support_shared_expert_fusion=not _disable_shared_experts_fusion(),
                # The stage boundary completes this stage's sum.
                reduce_results=False,
            )
        elif config.model_type == "qwen3_5_text":
            self.mlp = Qwen2MoeMLP(
                hidden_size=config.hidden_size,
                intermediate_size=config.intermediate_size,
                hidden_act=config.hidden_act,
                quant_config=quant_config,
                prefix=add_prefix("mlp", prefix.replace(".linear_attn", "")),
                # The stage boundary completes this stage's sum.
                reduce_results=False,
            )
            _maybe_enable_silu_fp4_quant_fusion(self.mlp)
        else:
            raise ValueError(f"Invalid model type: {config.model_type}")

        self.input_layernorm = GemmaRMSNorm(config.hidden_size, eps=config.rms_norm_eps)
        self.post_attention_layernorm = GemmaRMSNorm(
            config.hidden_size, eps=config.rms_norm_eps
        )
        # GDN layers need both bf16 (for the small in_proj_ba gating
        # projection) and a quantized tuple only when in_proj_qkvz can consume
        # it. Otherwise, stay on the plain AR+RMSNorm path.
        accepts_fp8_input = _linear_accepts_fp8_tuple(self.linear_attn.in_proj_qkvz)
        boundary_fusions = _layer_fusions(config, is_nextn)
        # A subclass that brings its own residual builds the stages itself.
        if build_stages:
            attn, ffn = self.stage_facts(
                config,
                layer_id,
                attn_read=NormQuantReadout(
                    fp8_input=Fp8Input.TUPLE_AND_BF16 if accepts_fp8_input else None
                ),
            )
            self.attn_boundary, self.ffn_boundary = append_stages(
                (attn, self.input_layernorm, {"fusions": boundary_fusions}),
                (ffn, self.post_attention_layernorm, {"fusions": boundary_fusions}),
            )

    def forward(
        self,
        hidden_states: torch.Tensor,
        **kwargs,
    ):
        forward_batch = kwargs.get("forward_batch", None)

        hidden_states = self.attn_boundary.prepare(
            hidden_states,
            forward_batch,
            capture_gathered=kwargs.get("captured_last_layer_outputs", None),
        )

        # fused AR+quant hands down a (fp8, scale) / (bf16, fp8, scale) tuple
        hs = hidden_states[0] if isinstance(hidden_states, tuple) else hidden_states
        if not forward_batch.forward_mode.is_idle() and hs.shape[0] > 0:
            hidden_states = self.linear_attn(
                hidden_states,
                forward_batch,
            )

        # Fully Connected
        hidden_states = self.attn_boundary.finish(hidden_states, forward_batch)
        hidden_states = self.ffn_boundary.prepare(hidden_states, forward_batch)

        with self.ffn_boundary.exit(forward_batch) as ffn_exit:
            if isinstance(self.mlp, Qwen2MoeSparseMoeBlock):
                hidden_states = self.mlp(
                    hidden_states,
                    forward_batch,
                    defer_finalize=ffn_exit.defer_moe_finalize,
                )
            else:
                hidden_states = self.mlp(hidden_states)
        return ffn_exit.finish(hidden_states)


def _refreshes_rope_cos_sin(
    config: Qwen3_5TextConfig, layer_id: int, is_nextn: bool
) -> bool:
    """rotary_emb is shared by all layers, so its per-forward cos/sin is refreshed
    once, at the first full-attention layer this PP stage owns.

    layer_id must be a full-attention layer; linear-attention layers near the
    stage start would also pass the check below. Only Qwen3_5AttentionDecoderLayer
    calls this, and it is built only for "attention" entries of layers_block_type.
    """
    # Drafts keep the unsplit numbering.
    stage_start = 0
    if not is_nextn:
        stage_start, _ = get_pp_indices(
            config.num_hidden_layers,
            get_parallel().pp_rank,
            get_parallel().pp_size,
        )
    owned_by_stage = layer_id >= stage_start
    # Full-attention layers are interval apart, so only the stage's first one
    # lies within interval of its start.
    first_in_stage = layer_id < stage_start + config.full_attention_interval
    return owned_by_stage and first_in_stage


class Qwen3_5AttentionDecoderLayer(nn.Module):
    """Qwen3.5 Decoder Layer with Full Attention."""

    stage_facts = staticmethod(_qwen3_5_stage_facts)

    def __init__(
        self,
        config: Qwen3_5TextConfig,
        layer_id: int,
        quant_config: Optional[QuantizationConfig] = None,
        prefix: str = "",
        alt_stream: Optional[torch.cuda.Stream] = None,
        is_nextn: bool = False,
        build_stages: bool = True,
    ) -> None:
        super().__init__()
        self.config = config
        self.hidden_size = config.hidden_size
        self.attn_tp_rank = get_parallel().attn_tp_rank
        self.attn_tp_size = get_parallel().attn_tp_size
        self.refreshes_rope_cos_sin = _refreshes_rope_cos_sin(
            config, layer_id, is_nextn
        )
        # A Qwen3.5 draft is rewritten to the MTP arch (model_config._config_draft_model),
        # so is_nextn marks it. Drafts are TP-sharded and do not replicate KV under DCP.
        dcp_size = 1 if is_nextn else get_parallel().attn_dcp_size
        kv_parallel_group = ReplicatedParallelGroup("attn_tp", dcp_size)
        self.kv_tp_rank, self.kv_tp_size = resolve_linear_parallel_group(
            kv_parallel_group
        )
        self.total_num_heads = config.num_attention_heads
        assert self.total_num_heads % self.attn_tp_size == 0
        self.num_heads = self.total_num_heads // self.attn_tp_size
        self.total_num_kv_heads = config.num_key_value_heads
        if self.total_num_kv_heads >= self.kv_tp_size:
            assert self.total_num_kv_heads % self.kv_tp_size == 0
        else:
            assert self.kv_tp_size % self.total_num_kv_heads == 0
        self.num_kv_heads = max(1, self.total_num_kv_heads // self.kv_tp_size)
        self.head_dim = config.head_dim or (self.hidden_size // self.num_heads)
        self.q_size = self.num_heads * self.head_dim
        self.kv_size = self.num_kv_heads * self.head_dim
        self.scaling = self.head_dim**-0.5
        self.max_position_embeddings = getattr(config, "max_position_embeddings", 8192)

        self.rope_theta, rope_scaling = get_rope_config(config)
        self.partial_rotary_factor = getattr(config, "partial_rotary_factor", 1.0)
        self.layer_id = layer_id

        # If rope_scaling doesn't specify a scaling type, treat as no scaling
        if rope_scaling and not ("rope_type" in rope_scaling or "type" in rope_scaling):
            rope_scaling = None

        self.attn_output_gate = getattr(config, "attn_output_gate", True)
        if self.attn_output_gate:
            logger.warning_once("using attn output gate!")

        self.rotary_emb = get_rope(
            head_size=self.head_dim,
            rotary_dim=self.head_dim,
            max_position=self.max_position_embeddings,
            rope_scaling=rope_scaling,
            base=self.rope_theta,
            partial_rotary_factor=self.partial_rotary_factor,
            is_neox_style=True,
            dtype=torch.get_default_dtype(),
        )

        # Q stays sharded across attention TP ranks; K/V are replicated within
        # each DCP group.
        self.qkv_proj = QKVParallelLinear(
            config.hidden_size,
            self.head_dim,
            self.total_num_heads * (1 + self.attn_output_gate),
            self.total_num_kv_heads,
            bias=False,
            quant_config=quant_config,
            parallel_group="attn_tp",
            kv_parallel_group=kv_parallel_group,
            prefix=add_prefix("qkv_proj", prefix),
        )

        self.o_proj = RowParallelLinear(
            self.total_num_heads * self.head_dim,
            config.hidden_size,
            bias=False,
            quant_config=quant_config,
            reduce_results=False,
            parallel_group="attn_tp",
            prefix=add_prefix("o_proj", prefix),
        )

        self.attn = RadixAttention(
            self.num_heads,
            self.head_dim,
            self.scaling,
            num_kv_heads=self.num_kv_heads,
            layer_id=layer_id,
            # Noncausal decision checkpoints let full attention see the whole prompt.
            attn_type=(
                AttentionType.DECODER
                if getattr(config, "is_causal", True)
                else AttentionType.ENCODER_ONLY
            ),
            prefix=f"{prefix}.attn",
            quant_config=quant_config,
        )

        # Dense MLP for non-MoE variant
        if config.model_type == "qwen3_5_text":
            self.mlp = Qwen2MoeMLP(
                hidden_size=config.hidden_size,
                intermediate_size=config.intermediate_size,
                hidden_act=config.hidden_act,
                quant_config=quant_config,
                prefix=add_prefix("mlp", prefix.replace(".self_attn", "")),
                # The stage boundary completes this stage's sum.
                reduce_results=False,
            )
        elif _qwen3_5_is_moe(config):
            self.mlp = Qwen2MoeSparseMoeBlock(
                layer_id=layer_id,
                config=config,
                quant_config=quant_config,
                alt_stream=(
                    alt_stream
                    if (_is_cuda or _disable_shared_experts_fusion())
                    else None
                ),
                prefix=add_prefix("mlp", prefix.replace(".self_attn", "")),
                is_nextn=is_nextn,
                support_shared_expert_fusion=not _disable_shared_experts_fusion(),
                # The stage boundary completes this stage's sum.
                reduce_results=False,
            )
        else:
            raise ValueError(f"Invalid model type: {config.model_type}")

        self.input_layernorm = GemmaRMSNorm(config.hidden_size, eps=config.rms_norm_eps)
        self.post_attention_layernorm = GemmaRMSNorm(
            config.hidden_size, eps=config.rms_norm_eps
        )

        self.q_norm = GemmaRMSNorm(self.head_dim, eps=config.rms_norm_eps)
        self.k_norm = GemmaRMSNorm(self.head_dim, eps=config.rms_norm_eps)

        # Standard attention layers benefit from a fused quant epilogue only
        # when qkv_proj can consume the returned quantized tuple.
        accepts_fp8_input = _linear_accepts_fp8_tuple(self.qkv_proj)
        boundary_fusions = _layer_fusions(config, is_nextn)
        # A subclass that brings its own residual builds the stages itself.
        if build_stages:
            attn, ffn = self.stage_facts(
                config,
                layer_id,
                attn_read=NormQuantReadout(
                    fp8_input=Fp8Input.TUPLE if accepts_fp8_input else None
                ),
            )
            self.attn_boundary, self.ffn_boundary = append_stages(
                (attn, self.input_layernorm, {"fusions": boundary_fusions}),
                (ffn, self.post_attention_layernorm, {"fusions": boundary_fusions}),
            )

        self.alt_stream = alt_stream

    def _apply_qk_norm(
        self, q: torch.Tensor, k: torch.Tensor
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """Apply Q/K normalization with optional alt_stream overlap."""
        if (
            self.alt_stream is not None
            and get_is_capture_mode()
            and _qknorm_use_alt_stream
        ):
            current_stream = torch.cuda.current_stream()
            self.alt_stream.wait_stream(current_stream)
            q_by_head = q.reshape(-1, self.head_dim)
            q_by_head = self.q_norm(q_by_head)
            with torch.cuda.stream(self.alt_stream):
                k_by_head = k.reshape(-1, self.head_dim)
                k_by_head = self.k_norm(k_by_head)
            current_stream.wait_stream(self.alt_stream)
        elif _is_hip or _is_xpu or _is_cpu:
            q_by_head, k_by_head = fused_qk_gemma_rmsnorm(
                q,
                k,
                self.q_norm.weight.data,
                self.k_norm.weight.data,
                self.q_norm.variance_epsilon,
                self.head_dim,
            )
        else:
            q_by_head = q.reshape(-1, self.head_dim)
            q_by_head = self.q_norm(q_by_head)
            k_by_head = k.reshape(-1, self.head_dim)
            k_by_head = self.k_norm(k_by_head)
        q = q_by_head.view(q.shape)
        k = k_by_head.view(k.shape)
        return q, k

    def forward_prepare_cuda_fused(self, positions, hidden_states):
        """Fused QK GemmaRMSNorm + NeoX RoPE + gate deinterleave."""
        qkv, _ = self.qkv_proj(hidden_states)
        if self.attn_output_gate:
            q_gate, k, v = qkv.split(
                [self.q_size * 2, self.kv_size, self.kv_size], dim=-1
            )
        else:
            q_gate, k, v = qkv.split([self.q_size, self.kv_size, self.kv_size], dim=-1)
        q_out, k_out, gate_out = fused_qk_gemma_rmsnorm_rope_gate(
            q_gate,
            k,
            self.q_norm.weight.data,
            self.k_norm.weight.data,
            self.rotary_emb.cos_sin_cache,
            positions,
            self.q_norm.variance_epsilon,
            self.num_heads,
            self.num_kv_heads,
            self.head_dim,
            self.rotary_emb.rotary_dim,
            has_gate=self.attn_output_gate,
            mrope_axis_map=(self.rotary_emb.axis_map if positions.dim() == 2 else None),
        )
        seq_len = hidden_states.shape[0]
        q = q_out.view(seq_len, -1)
        k = k_out.view(seq_len, -1)
        gate = gate_out.view(seq_len, -1) if gate_out is not None else None
        return q, k, v, gate

    def forward_prepare_native(self, positions, hidden_states):
        if _use_aiter and isinstance(hidden_states, tuple):
            hidden_states = _select_fused_ar_input_for_linear(
                hidden_states, self.qkv_proj
            )
        qkv, _ = self.qkv_proj(hidden_states)
        if self.attn_output_gate:
            q_gate, k, v = qkv.split(
                [self.q_size * 2, self.kv_size, self.kv_size], dim=-1
            )
            orig_shape = q_gate.shape[:-1]
            q_gate = q_gate.view(*orig_shape, self.num_heads, -1)
            q, gate = torch.chunk(q_gate, 2, dim=-1)
            q = q.reshape(*orig_shape, -1)
            # gate stays as 3D strided view; fused_sigmoid_mul handles it directly
        else:
            q, k, v = qkv.split([self.q_size, self.kv_size, self.kv_size], dim=-1)
            gate = None

        q, k = self._apply_qk_norm(q, k)
        q, k = self.rotary_emb(positions, q, k)
        return q, k, v, gate

    def forward_prepare_fused_gate(self, positions, hidden_states):
        if _use_aiter and isinstance(hidden_states, tuple):
            hidden_states = _select_fused_ar_input_for_linear(
                hidden_states, self.qkv_proj
            )
        qkv, _ = self.qkv_proj(hidden_states)
        if self.attn_output_gate:
            q_gate, k, v = qkv.split(
                [self.q_size * 2, self.kv_size, self.kv_size], dim=-1
            )
            seq_len = q_gate.shape[0]
            q_flat, k_flat, gate_flat = fused_qk_gemma_rmsnorm_with_gate(
                q_gate,
                k,
                self.q_norm.weight.data,
                self.k_norm.weight.data,
                self.q_norm.variance_epsilon,
                self.head_dim,
                self.num_heads,
            )
            q = q_flat.view(seq_len, -1)
            k = k_flat.view(seq_len, -1)
            gate = gate_flat.view(seq_len, -1)
        else:
            q, k, v = qkv.split([self.q_size, self.kv_size, self.kv_size], dim=-1)
            gate = None
            q, k = self._apply_qk_norm(q, k)

        q, k = self.rotary_emb(positions, q, k)
        return q, k, v, gate

    def forward_prepare_npu(self, positions, hidden_states, forward_batch):
        qkv, _ = self.qkv_proj(hidden_states)
        if self.refreshes_rope_cos_sin:
            self.rotary_emb.get_cos_sin_with_position(positions)

        q, k, v, gate = split_qkvgate_gemma_rmsnorm_rope(
            qkv,
            self.rotary_emb.position_sin,
            self.rotary_emb.position_cos,
            self.q_size,
            self.kv_size,
            self.head_dim,
            int(self.head_dim * self.partial_rotary_factor),
            eps=self.q_norm.variance_epsilon,
            q_weight=self.q_norm.weight,
            k_weight=self.k_norm.weight,
        )
        return q, k, v, gate

    def _prepare_qkv_gate(
        self,
        positions: torch.Tensor,
        hidden_states: torch.Tensor,
        forward_batch: ForwardBatch,
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor, Optional[torch.Tensor]]:
        if _is_cuda and self.attn_output_gate:
            return self.forward_prepare_cuda_fused(
                positions=positions,
                hidden_states=hidden_states,
            )
        if (_is_hip or _is_xpu or _is_cpu) and self.attn_output_gate:
            return self.forward_prepare_fused_gate(
                positions=positions,
                hidden_states=hidden_states,
            )
        if (
            not _is_npu
            or forward_batch.forward_mode.is_extend_or_draft_extend_or_mixed()
            or not self.attn_output_gate
        ):
            return self.forward_prepare_native(
                positions=positions,
                hidden_states=hidden_states,
            )
        return self.forward_prepare_npu(
            positions=positions,
            hidden_states=hidden_states,
            forward_batch=forward_batch,
        )

    def self_attention(
        self,
        positions: torch.Tensor,
        hidden_states: torch.Tensor,
        forward_batch: ForwardBatch,
    ) -> torch.Tensor:
        """Full attention forward pass."""
        q, k, v, gate = self._prepare_qkv_gate(
            positions=positions,
            hidden_states=hidden_states,
            forward_batch=forward_batch,
        )

        attn_output = self.attn(q, k, v, forward_batch)

        if self.attn_output_gate:
            if _fp8_tuple_input(self.o_proj, attn_output.shape[0]):
                attn_output = fused_sigmoid_mul(attn_output, gate, quant=True)
            elif not _is_npu:
                attn_output = fused_sigmoid_mul(attn_output, gate, inplace=True)
            else:
                gate_val = gate.reshape(gate.shape[0], -1) if gate.ndim == 3 else gate
                attn_output = npu_fused_sigmoid_mul(attn_output, gate_val.contiguous())

        output, _ = self.o_proj(attn_output)
        return output

    def forward(
        self,
        positions: torch.Tensor,
        hidden_states: torch.Tensor,
        forward_batch: ForwardBatch,
        captured_last_layer_outputs: Optional[AuxHiddenStateAccumulator] = None,
        **kwargs,
    ):
        hidden_states = self.attn_boundary.prepare(
            hidden_states,
            forward_batch,
            capture_gathered=captured_last_layer_outputs,
        )

        # fused AR+quant hands down a (fp8, scale) / (bf16, fp8, scale) tuple
        hs = hidden_states[0] if isinstance(hidden_states, tuple) else hidden_states
        if not forward_batch.forward_mode.is_idle() and hs.shape[0] > 0:
            hidden_states = self.self_attention(
                positions=positions,
                hidden_states=hidden_states,
                forward_batch=forward_batch,
            )

        # Fully Connected
        hidden_states = self.attn_boundary.finish(hidden_states, forward_batch)
        hidden_states = self.ffn_boundary.prepare(hidden_states, forward_batch)
        with self.ffn_boundary.exit(forward_batch) as ffn_exit:
            if isinstance(self.mlp, Qwen2MoeSparseMoeBlock):
                hidden_states = self.mlp(
                    hidden_states,
                    forward_batch,
                    defer_finalize=ffn_exit.defer_moe_finalize,
                )
            else:
                hidden_states = self.mlp(hidden_states)
        return ffn_exit.finish(hidden_states)


ALL_DECODER_LAYER_TYPES = {
    "attention": Qwen3_5AttentionDecoderLayer,
    "linear_attention": Qwen3_5LinearDecoderLayer,
}

# ModelOpt FP4 checkpoints bake the per-layer KV-cache scales under the HF
# attention projections; in sglang they live on RadixAttention. Apply this to the
# weight stream at the top of load_weights(), before ".self_attn" is stripped and
# before the stacked qkv_proj matching would consume the name.
QWEN3_5_KV_SCALE_MAPPER = WeightsMapper(
    orig_to_new_substr={
        ".self_attn.k_proj.k_scale": ".attn.k_scale",
        ".self_attn.v_proj.v_scale": ".attn.v_scale",
        # compressed-tensors stores kv_cache_scheme scales on the attention module.
        ".self_attn.k_scale": ".attn.k_scale",
        ".self_attn.v_scale": ".attn.v_scale",
    },
)


class Qwen3_5ForCausalLM(nn.Module):
    """Qwen3.5 Model with support for dense variant."""

    decoder_layer_types = ALL_DECODER_LAYER_TYPES

    packed_modules_mapping = {
        "qkv_proj": ["q_proj", "k_proj", "v_proj"],
        "gate_up_proj": ["gate_proj", "up_proj"],
        "in_proj_qkvz": ["in_proj_qkv", "in_proj_z"],
        "in_proj_ba": ["in_proj_b", "in_proj_a"],
    }

    supported_lora_modules = [
        "qkv_proj",
        "o_proj",
        "out_proj",
        "in_proj_qkvz",
        "gate_up_proj",
        "down_proj",
        "lm_head",
    ]

    def get_hidden_dim(self, module_name: str, layer_idx: int):
        config = self.config
        head_dim = config.head_dim or (config.hidden_size // config.num_attention_heads)

        if module_name == "qkv_proj":
            attn_output_gate = getattr(config, "attn_output_gate", True)
            q_heads = config.num_attention_heads * (2 if attn_output_gate else 1)
            return (
                config.hidden_size,
                head_dim * (q_heads + config.num_key_value_heads * 2),
            )
        elif module_name == "o_proj":
            return config.num_attention_heads * head_dim, config.hidden_size
        elif module_name == "out_proj":
            value_dim = config.linear_value_head_dim * config.linear_num_value_heads
            return value_dim, config.hidden_size
        elif module_name == "in_proj_qkvz":
            key_dim = config.linear_key_head_dim * config.linear_num_key_heads
            value_dim = config.linear_value_head_dim * config.linear_num_value_heads
            return config.hidden_size, key_dim * 2 + value_dim * 2
        elif module_name == "gate_up_proj":
            # MoE: shared expert uses shared_expert_intermediate_size
            # Dense: regular MLP uses intermediate_size
            is_moe = config.model_type in _QWEN3_5_MOE_TEXT_MODEL_TYPES
            if is_moe:
                inter = config.shared_expert_intermediate_size
            else:
                inter = config.intermediate_size
            return config.hidden_size, inter * 2
        elif module_name == "down_proj":
            is_moe = config.model_type in _QWEN3_5_MOE_TEXT_MODEL_TYPES
            if is_moe:
                inter = config.shared_expert_intermediate_size
            else:
                inter = config.intermediate_size
            return inter, config.hidden_size
        elif module_name == "gate_up_proj_moe":
            return config.hidden_size, config.moe_intermediate_size * 2
        elif module_name == "down_proj_moe":
            return config.moe_intermediate_size, config.hidden_size
        elif module_name == "embed_tokens":
            return config.vocab_size, config.hidden_size
        elif module_name == "lm_head":
            return config.hidden_size, config.vocab_size
        else:
            raise NotImplementedError(
                f"get_hidden_dim not implemented for {module_name}"
            )

    def __init__(
        self,
        config: Qwen3_5TextConfig,
        quant_config: Optional[QuantizationConfig] = None,
        prefix: str = "",
        is_nextn: bool = False,
    ) -> None:
        super().__init__()
        self.config = config
        self.hidden_size = config.hidden_size
        self.pp_group = get_parallel().pp_group

        alt_stream = get_stream("alt") if _is_cuda or _hip_use_alt_stream else None

        # Embedding layer
        self.embed_tokens = self._build_embed_tokens(config)

        # Decoder layers
        def get_layer(idx: int, prefix: str):
            layer_type = config.layers_block_type[idx]
            layer_class = self.decoder_layer_types[layer_type]
            if layer_type == "attention":
                prefix = add_prefix("self_attn", prefix)
            else:
                prefix = add_prefix("linear_attn", prefix)
            return layer_class(
                config=config,
                layer_id=idx,
                quant_config=quant_config,
                prefix=prefix,
                alt_stream=alt_stream,
                is_nextn=is_nextn,
            )

        self.layers, self._start_layer, self._end_layer = make_pp_layers(
            config.num_hidden_layers,
            get_layer,
            prefix=f"{prefix}.layers",
            # The layer type chosen for each index declares its stages.
            stage_facts=lambda idx: self.decoder_layer_types[
                config.layers_block_type[idx]
            ].stage_facts(config, idx),
        )

        self.flashinfer_mnnvl_cutedsl_fusion = None
        if _use_mnnvl_cutedsl_fusion(config, is_nextn):
            if self.pp_group.world_size != 1:
                raise RuntimeError(
                    "Qwen3.5 FlashInfer MNNVL CuTe DSL fusion currently requires PP=1"
                )
            unsupported_layers = [
                layer.layer_id
                for layer in self.layers
                if not isinstance(layer.mlp, Qwen2MoeSparseMoeBlock)
                or not layer.mlp.supports_deferred_finalize
            ]
            if unsupported_layers:
                raise RuntimeError(
                    "Qwen3.5 FlashInfer MNNVL CuTe DSL fusion currently "
                    "requires block-FP8 MoE weights with FlashInfer TRTLLM "
                    "deferred-finalize support on every layer; unsupported "
                    "layers: "
                    f"{unsupported_layers}"
                )
            from sglang.srt.layers.layer_boundary.fusions.cutedsl import (
                install_cutedsl_fusion,
            )

            self.flashinfer_mnnvl_cutedsl_fusion = install_cutedsl_fusion(
                self.layers,
                hidden_size=config.hidden_size,
                top_k=config.num_experts_per_tok,
                rms_epsilon=config.rms_norm_eps,
                # Every layer was checked above.
                can_defer_finalize=lambda layer: True,
                label="Qwen3.5",
                # The final GemmaRMSNorm consumes a finalize handoff.
                terminal_finalize=True,
            )

        # Final normalization
        if self.pp_group.is_last_rank:
            self.norm = GemmaRMSNorm(config.hidden_size, eps=config.rms_norm_eps)
        else:
            self.norm = PPMissingLayer()

        self.layers_to_capture = []

    def _build_embed_tokens(self, config: Qwen3_5TextConfig) -> nn.Module:
        """Embedding sharding hook for models reusing this backbone."""
        if not self.pp_group.is_first_rank:
            return PPMissingLayer()
        return VocabParallelEmbedding(
            config.vocab_size,
            config.hidden_size,
            org_num_embeddings=config.vocab_size,
            enable_tp=not is_dp_attention_enabled(),
        )

    def get_input_embeddings(self):
        return self.embed_tokens

    def prepare_before_cuda_graph_capture(self, model_runner) -> None:
        if _use_aiter and self.config.model_type in _QWEN3_5_ROCM_PACKED_MODEL_TYPES:
            packed = 0
            for module in self.modules():
                if isinstance(module, Qwen3_5GatedDeltaNet):
                    module.finalize_fused_in_proj()
                    packed += int(module._fused_in_proj_weight is not None)
            logger.info(
                "Packed BF16/FP8 GDN input projection enabled for %d layers", packed
            )

    def set_dflash_layers_to_capture(self, layers_to_capture: list[int]):
        self.layers_to_capture = layers_to_capture
        for layer_id in self.layers_to_capture:
            setattr(self.layers[layer_id], "_is_layer_to_capture", True)

    def set_eagle3_layers_to_capture(self, layers_to_capture: list[int]):
        self.layers_to_capture = layers_to_capture
        for layer_id in self.layers_to_capture:
            setattr(self.layers[layer_id], "_is_layer_to_capture", True)

    @property
    def start_layer(self) -> int:
        return self._start_layer

    @property
    def end_layer(self) -> int:
        return self._end_layer

    @torch.no_grad()
    def forward(
        self,
        input_ids: torch.Tensor,
        positions: torch.Tensor,
        forward_batch: ForwardBatch,
        input_embeds: Optional[torch.Tensor] = None,
        pp_proxy_tensors: Optional[PPProxyTensors] = None,
        input_deepstack_embeds: Optional[torch.Tensor] = None,
    ) -> Union[torch.Tensor, PPProxyTensors]:
        if (
            self.flashinfer_mnnvl_cutedsl_fusion is not None
            and input_deepstack_embeds is not None
            and input_deepstack_embeds.numel() > 0
        ):
            raise RuntimeError(
                "Qwen3.5 FlashInfer MNNVL CuTe DSL fusion currently supports "
                "the text-only path, not deepstack visual inputs"
            )

        # Initialize hidden states
        if self.pp_group.is_first_rank:
            if input_embeds is None:
                hidden_states = self.embed_tokens(input_ids)
            else:
                hidden_states = input_embeds
            residual_batch.start(forward_batch)
        else:
            assert pp_proxy_tensors is not None
            hidden_states = self.layers[self.start_layer].attn_boundary.from_pp(
                pp_proxy_tensors, forward_batch
            )

        aux_hidden_states = AuxHiddenStateList()
        # Pass through decoder layers
        for layer_idx in range(self.start_layer, self.end_layer):
            layer = self.layers[layer_idx]
            with get_global_expert_distribution_recorder().with_current_layer(
                layer_idx
            ):
                hidden_states = layer(
                    positions=positions,
                    hidden_states=hidden_states,
                    forward_batch=forward_batch,
                    captured_last_layer_outputs=aux_hidden_states
                    if getattr(layer, "_is_layer_to_capture", False)
                    else None,
                )

            # Process deepstack embeddings if provided
            if (
                input_deepstack_embeds is not None
                and input_deepstack_embeds.numel() > 0
                and layer_idx < 3
            ):
                sep = self.hidden_size * layer_idx
                hidden_states = residual_batch.add_to_output(
                    hidden_states,
                    forward_batch,
                    input_deepstack_embeds[:, sep : sep + self.hidden_size],
                )

        if not self.pp_group.is_last_rank:
            return residual_batch.to_pp(hidden_states, forward_batch)

        hidden_states = residual_batch.final_norm(
            hidden_states,
            forward_batch,
            self.norm,
            finalize_norm=self.flashinfer_mnnvl_cutedsl_fusion,
            skip_empty=True,
        )

        if len(aux_hidden_states) == 0:
            return hidden_states

        return hidden_states, aux_hidden_states

    def load_weights(self, weights: Iterable[Tuple[str, torch.Tensor]]):
        weights = QWEN3_5_KV_SCALE_MAPPER.apply(weights)
        stacked_params_mapping = [
            # (param_name, shard_name, shard_id)
            ("qkv_proj", "q_proj", "q"),
            ("qkv_proj", "k_proj", "k"),
            ("qkv_proj", "v_proj", "v"),
            ("gate_up_proj", "gate_proj", 0),
            ("gate_up_proj", "up_proj", 1),
            # GDN
            ("in_proj_qkvz.", "in_proj_qkv.", (0, 1, 2)),
            ("in_proj_qkvz.", "in_proj_z.", 3),
            ("in_proj_ba.", "in_proj_b.", 0),
            ("in_proj_ba.", "in_proj_a.", 1),
        ]

        loaded_params: Set[str] = set()
        params_dict = dict(self.named_parameters(remove_duplicate=False))
        for name, loaded_weight in weights:
            if "rotary_emb.inv_freq" in name:
                continue
            if "mtp" in name:
                continue
            if "visual" in name:
                continue
            if "language_model" in name:
                name = name.replace(r"model.language_model.", r"model.")
            if ".self_attn." in name:
                name = name.replace(".self_attn", "")
            layer_id = get_layer_id(name)
            if (
                layer_id is not None
                and hasattr(self, "start_layer")
                and (layer_id < self.start_layer or layer_id >= self.end_layer)
            ):
                continue

            for param_name, weight_name, shard_id in stacked_params_mapping:
                if weight_name not in name:
                    continue

                if "mlp.experts" in name:
                    continue

                name = name.replace(weight_name, param_name)
                # Skip loading extra bias for GPTQ models.
                if name.endswith(".bias") and name not in params_dict:
                    continue
                # Skip layers on other devices.
                # if is_pp_missing_parameter(name, self):
                #     continue
                if name not in params_dict:
                    continue
                param = params_dict[name]
                weight_loader = getattr(param, "weight_loader")
                weight_loader(param, loaded_weight, shard_id)
                break
            else:
                # Skip loading extra bias for GPTQ models.
                if name.endswith(".bias") and name not in params_dict:
                    continue
                if name not in params_dict:
                    logger.warning(f"Parameter {name} not found in params_dict")
                    continue
                param = params_dict[name]

                weight_loader = getattr(param, "weight_loader", default_weight_loader)
                weight_loader(param, loaded_weight)
            loaded_params.add(name)
        return loaded_params

    @classmethod
    def get_model_config_for_expert_location(cls, config):
        return ModelConfigForExpertLocation(
            num_layers=config.num_hidden_layers,
            num_logical_experts=config.num_experts,
            num_groups=None,
        )


class Qwen3_5MoeForCausalLM(Qwen3_5ForCausalLM):
    def __init__(
        self,
        config: Qwen3_5TextConfig,
        quant_config: Optional[QuantizationConfig] = None,
        prefix: str = "",
    ) -> None:
        super().__init__(config=config, quant_config=quant_config, prefix=prefix)
        # When aiter shared-expert fusion is on, the shared expert is served as an
        # extra fused MoE slot (index == num_experts). load_weights must then remap
        # the checkpoint's mlp.shared_expert.* onto that slot; otherwise the shared
        # expert weights are silently dropped and accuracy collapses.
        self.num_fused_shared_experts = 0
        if _use_aiter and not _disable_shared_experts_fusion():
            self.num_fused_shared_experts = self._get_num_fused_shared_experts()
        self.enable_shared_expert_fusion = self.num_fused_shared_experts > 0

    def _get_num_fused_shared_experts(self) -> int:
        # This is a backbone-style module (holds self.layers directly), and under
        # PP the non-local slots are PPMissingLayer (no .mlp), so scan for the
        # first real MoE layer instead of assuming layers[0].
        for layer in self.layers:
            if hasattr(layer, "mlp") and hasattr(layer.mlp, "num_fused_shared_experts"):
                return layer.mlp.num_fused_shared_experts
        return 0

    def load_weights(self, weights: Iterable[Tuple[str, torch.Tensor]]):
        weights = QWEN3_5_KV_SCALE_MAPPER.apply(weights)
        stacked_params_mapping = [
            # (param_name, shard_name, shard_id)
            ("qkv_proj", "q_proj", "q"),
            ("qkv_proj", "k_proj", "k"),
            ("qkv_proj", "v_proj", "v"),
            ("gate_up_proj", "gate_proj", 0),
            ("gate_up_proj", "up_proj", 1),
            # GDN
            ("in_proj_qkvz.", "in_proj_qkv.", (0, 1, 2)),
            ("in_proj_qkvz.", "in_proj_z.", 3),
            ("in_proj_ba.", "in_proj_b.", 0),
            ("in_proj_ba.", "in_proj_a.", 1),
        ]

        num_experts = self.config.num_experts

        # Params for weights, fp8 weight scales, fp8 activation scales
        # (param_name, weight_name, expert_id, shard_id)
        expert_params_mapping = FusedMoE.make_expert_params_mapping(
            ckpt_gate_proj_name="gate_proj",
            ckpt_down_proj_name="down_proj",
            ckpt_up_proj_name="up_proj",
            num_experts=(
                num_experts
                if not self.enable_shared_expert_fusion
                else num_experts + self.num_fused_shared_experts
            ),
        )

        # Skip loading extra parameters for GPTQ/modelopt models.
        ignore_suffixes = (
            ".bias",
            "_bias",
            ".k_scale",
            "_k_scale",
            ".v_scale",
            "_v_scale",
            ".weight_scale",
            "_weight_scale",
            ".input_scale",
            "_input_scale",
        )

        is_fused_expert = False
        fused_expert_params_mapping = [
            ("experts.w13_weight", "experts.gate_up_proj", 0, "w1"),
            ("experts.w2_weight", "experts.down_proj", 0, "w2"),
        ]

        if self.enable_shared_expert_fusion:
            # When shared experts are fused, map them to the extra routed slot:
            #   mlp.shared_expert.gate_up_proj -> experts.{num_experts}.gate_up_proj -> w13, expert_id=num_experts
            #   mlp.shared_expert.down_proj    -> experts.{num_experts}.down_proj    -> w2,  expert_id=num_experts
            fused_expert_params_mapping += [
                (
                    "experts.w13_",
                    f"experts.{num_experts}.gate_up_proj.",
                    num_experts,
                    "w1",
                ),
                (
                    "experts.w2_",
                    f"experts.{num_experts}.down_proj.",
                    num_experts,
                    "w2",
                ),
                ## shared experts may contain gate_proj and up_proj instead of gate_up_proj
                (
                    "experts.w13_",
                    f"experts.{num_experts}.gate_proj.",
                    num_experts,
                    "w1",
                ),
                (
                    "experts.w13_",
                    f"experts.{num_experts}.up_proj.",
                    num_experts,
                    "w3",
                ),
            ]

        def load_fused_expert_weights(
            name: str,
            params_dict: dict,
            loaded_weight: torch.Tensor,
            shard_id: str,
            num_experts: int,
        ):
            if name not in params_dict:
                return False
            param = params_dict[name]
            weight_loader = param.weight_loader
            # let ep moe layer to gracefully handle expert_ids that do not belong to local moe rank
            for expert_id in range(num_experts):
                curr_expert_weight = loaded_weight[expert_id]
                weight_loader(
                    param,
                    curr_expert_weight,
                    name,
                    shard_id,
                    expert_id,
                )
            return True

        loaded_params: Set[str] = set()
        params_dict = dict(self.named_parameters(remove_duplicate=False))

        for name, loaded_weight in weights:
            if "rotary_emb.inv_freq" in name:
                continue
            if "mtp" in name:
                continue
            if "visual" in name:
                continue
            if "language_model" in name:
                name = name.replace(r"model.language_model.", r"model.")
            if ".self_attn." in name:
                name = name.replace(".self_attn", "")

            layer_id = get_layer_id(name)
            if (
                layer_id is not None
                and hasattr(self, "start_layer")
                and (layer_id < self.start_layer or layer_id >= self.end_layer)
            ):
                continue

            if self.enable_shared_expert_fusion and "mlp.shared_expert." in name:
                # Firstly map mlp.shared_expert.xx_proj to mlp.experts.{num_experts}.xx_proj
                name = name.replace(
                    "mlp.shared_expert.",
                    f"mlp.experts.{num_experts}.",
                )

            for param_name, weight_name, shard_id in stacked_params_mapping:
                if "experts.gate_up_proj" in name or "experts.down_proj" in name:
                    is_fused_expert = True
                    expert_params_mapping = fused_expert_params_mapping

                # Skip non-stacked layers and experts (experts handled below).
                if weight_name not in name:
                    continue

                # We have mlp.experts[0].gate_proj in the checkpoint.
                # Since we handle the experts below in expert_params_mapping,
                # we need to skip here BEFORE we update the name, otherwise
                # name will be updated to mlp.experts[0].gate_up_proj, which
                # will then be updated below in expert_params_mapping
                # for mlp.experts[0].gate_gate_up_proj, which breaks load.
                if "mlp.experts" in name:
                    continue
                name = name.replace(weight_name, param_name)
                # Skip loading extra parameters for GPTQ/modelopt models.
                if name.endswith(ignore_suffixes) and name not in params_dict:
                    continue

                if name not in params_dict:
                    continue

                param = params_dict[name]
                weight_loader = param.weight_loader
                weight_loader(param, loaded_weight, shard_id)
                break
            else:
                # Track if this is an expert weight to enable early skipping
                is_expert_weight = False

                for mapping in expert_params_mapping:
                    param_name, weight_name, expert_id, shard_id = mapping
                    if weight_name not in name:
                        continue
                    # Anyway, this is an expert weight and should not be
                    # attempted to load as other weights later
                    is_expert_weight = True
                    name_mapped = name.replace(weight_name, param_name)
                    if is_fused_expert:
                        # is_fused_expert is True, the checkpoint contains gate_up_proj and down_proj for each expert
                        if "experts.gate_up_proj" in name:
                            # experts.gate_up_proj contains all routed experts, excluding shared experts
                            loaded_weight = loaded_weight.chunk(2, dim=-2)
                            load_fused_expert_weights(
                                name_mapped,
                                params_dict,
                                loaded_weight[0],
                                "w1",
                                num_experts,
                            )
                            load_fused_expert_weights(
                                name_mapped,
                                params_dict,
                                loaded_weight[1],
                                "w3",
                                num_experts,
                            )
                        elif "experts.down_proj" in name:
                            # experts.down_proj contains all routed experts, excluding shared experts
                            load_fused_expert_weights(
                                name_mapped,
                                params_dict,
                                loaded_weight,
                                shard_id,
                                num_experts,
                            )
                        elif self.enable_shared_expert_fusion:
                            # shared experts should be loaded to experts.w13_weight and experts.w2_weight
                            param = params_dict[name_mapped]
                            weight_loader = getattr(
                                param, "weight_loader", default_weight_loader
                            )
                            if f"{num_experts}.gate_up_proj" in name:
                                # split into w1 and w3
                                loaded_weight = loaded_weight.chunk(2, dim=-2)
                                # load to experts.w13_weight, shard_id = w1, expert_id = num_experts
                                weight_loader(
                                    param,
                                    loaded_weight[0],
                                    name_mapped,
                                    "w1",
                                    expert_id,
                                )
                                # load to experts.w13_weight, shard_id = w3, expert_id = num_experts
                                weight_loader(
                                    param,
                                    loaded_weight[1],
                                    name_mapped,
                                    "w3",
                                    expert_id,
                                )
                            else:
                                # load down_proj to experts.w2_weight, shard_id = w2, expert_id = num_experts
                                # Or load gate_proj and up_proj to experts.w13_weight, shard_id = w1/w3, expert_id = num_experts
                                weight_loader(
                                    param,
                                    loaded_weight,
                                    name_mapped,
                                    shard_id,
                                    expert_id,
                                )
                    else:
                        # Skip loading extra parameters for GPTQ/modelopt models.
                        if (
                            name_mapped.endswith(ignore_suffixes)
                            and name_mapped not in params_dict
                        ):
                            continue
                        param = params_dict[name_mapped]
                        # We should ask the weight loader to return success or
                        # not here since otherwise we may skip experts with
                        # # other available replicas.
                        weight_loader = param.weight_loader
                        weight_loader(
                            param,
                            loaded_weight,
                            name_mapped,
                            shard_id=shard_id,
                            expert_id=expert_id,
                        )
                    name = name_mapped
                    break
                else:
                    if is_expert_weight:
                        # This is an expert weight but not mapped to this rank, skip all remaining processing
                        continue

                    # Skip loading extra parameters for GPTQ/modelopt models.
                    if name.endswith(ignore_suffixes) and name not in params_dict:
                        continue

                    if name in params_dict.keys():
                        param = params_dict[name]
                        weight_loader = getattr(
                            param, "weight_loader", default_weight_loader
                        )
                        weight_loader(param, loaded_weight)
                    else:
                        logger.warning(f"Parameter {name} not found in params_dict")
            loaded_params.add(name)

        return loaded_params


class Qwen3_5ForConditionalGeneration(Qwen3VLForConditionalGeneration):
    packed_modules_mapping = Qwen3_5ForCausalLM.packed_modules_mapping
    hf_to_sglang_mapper = None

    supported_lora_modules = Qwen3_5ForCausalLM.supported_lora_modules

    def __init__(
        self,
        config: Qwen3_5Config,
        quant_config: Optional[QuantizationConfig] = None,
        prefix: str = "",
        language_model_cls=Qwen3_5ForCausalLM,
    ):
        super().__init__(config, quant_config, prefix, language_model_cls)

        rope_config = getattr(self.config, "rope_parameters", None) or getattr(
            self.config, "rope_scaling", {}
        )
        self.is_mrope_enabled = (
            not self.language_model_only and "mrope_section" in rope_config
        )

        self.deepstack_visual_indexes = (
            self.visual.deepstack_visual_indexes if self.visual is not None else []
        )

        if config.architectures == ["Qwen3_5ForConditionalGeneration"]:
            model = get_model()
            joint_head_config = load_joint_head_config(model.model_path, model.revision)
            if joint_head_config is not None:
                # A Clef checkpoint, whose joint schema head scores every option
                # of every question from the final hidden states and LM head rows.
                self.pooler = JointSchemaPooler(
                    JointSchemaHead(**joint_head_config), lambda: self.lm_head.weight
                )

    def get_hidden_dim(self, module_name: str, layer_idx: int):
        return self.model.get_hidden_dim(module_name, layer_idx)

    def should_apply_lora(self, module_name: str) -> bool:
        return module_name.startswith("model.layers.")

    @property
    def start_layer(self) -> int:
        return getattr(getattr(self, "model", None), "start_layer", 0)

    @property
    def end_layer(self) -> int:
        model = getattr(self, "model", None)
        end_layer = getattr(model, "end_layer", None)
        if end_layer is not None:
            return end_layer
        cfg = getattr(model, "config", None)
        return int(getattr(cfg, "num_hidden_layers", 0))

    def get_embed_and_head(self):
        embed = self.model.embed_tokens.weight if self.pp_group.is_first_rank else None
        head = self.lm_head.weight if self.pp_group.is_last_rank else None
        return embed, head

    def set_embed_and_head(self, embed, head):
        if self.pp_group.is_first_rank and embed is not None:
            del self.model.embed_tokens.weight
            self.model.embed_tokens.weight = embed
        if self.pp_group.is_last_rank and head is not None:
            del self.lm_head.weight
            self.lm_head.weight = head
        if _is_xpu:
            torch.xpu.empty_cache()
            torch.xpu.synchronize()
        else:
            torch.cuda.empty_cache()
            torch.cuda.synchronize()

    def load_weights(self, weights: Iterable[Tuple[str, torch.Tensor]]):
        weights = QWEN3_5_KV_SCALE_MAPPER.apply(weights)
        stacked_params_mapping = [
            # (param_name, shard_name, shard_id)
            ("qkv_proj", "q_proj", "q"),
            ("qkv_proj", "k_proj", "k"),
            ("qkv_proj", "v_proj", "v"),
            ("gate_up_proj", "gate_proj", 0),
            ("gate_up_proj", "up_proj", 1),
            # GDN fused projections
            ("in_proj_qkvz.", "in_proj_qkv.", (0, 1, 2)),
            ("in_proj_qkvz.", "in_proj_z.", 3),
            ("in_proj_ba.", "in_proj_b.", 0),
            ("in_proj_ba.", "in_proj_a.", 1),
        ]

        loaded_params: Set[str] = set()
        params_dict = dict(self.named_parameters(remove_duplicate=False))
        bare_backbone = False
        for name, loaded_weight in weights:
            if "rotary_emb.inv_freq" in name:
                continue
            if "mtp" in name:
                continue
            if name.startswith("language_model."):
                # A bare Qwen3_5Model save, which has no LM head of its own.
                name = "model." + name
                bare_backbone = True
            if "language_model" in name:
                name = name.replace(r"model.language_model.", r"model.")
            if ".self_attn." in name:
                name = name.replace(".self_attn", "")
            if (
                self.config.tie_word_embeddings
                and self.pp_group.is_last_rank
                and "model.embed_tokens.weight" in name
            ):
                if "lm_head.weight" in params_dict:
                    lm_head_param = params_dict["lm_head.weight"]
                    weight_loader = getattr(
                        lm_head_param, "weight_loader", default_weight_loader
                    )
                    weight_loader(lm_head_param, loaded_weight)
            layer_id = get_layer_id(name)
            if (
                layer_id is not None
                and hasattr(self, "start_layer")
                and (layer_id < self.start_layer or layer_id >= self.end_layer)
            ):
                continue

            for param_name, weight_name, shard_id in stacked_params_mapping:
                if weight_name not in name:
                    continue

                if "visual" in name or "mlp.experts" in name:
                    continue

                name = name.replace(weight_name, param_name)
                # Skip loading extra bias for GPTQ models.
                if name.endswith(".bias") and name not in params_dict:
                    continue
                # Skip layers on other devices.
                # if is_pp_missing_parameter(name, self):
                #     continue
                if name not in params_dict:
                    continue
                param = params_dict[name]
                weight_loader = getattr(param, "weight_loader")
                weight_loader(param, loaded_weight, shard_id)
                break
            else:
                if "visual" in name:
                    # adapt to VisionAttention
                    name = name.replace(r"attn.qkv.", r"attn.qkv_proj.")
                    name = name.replace(r"model.visual.", r"visual.")

                # print(name, loaded_weight.shape)
                # Skip loading extra bias for GPTQ models.
                if name.endswith(".bias") and name not in params_dict:
                    continue
                if name not in params_dict:
                    logger.warning(f"Parameter {name} not found in params_dict")
                    continue
                param = params_dict[name]

                weight_loader = getattr(param, "weight_loader", default_weight_loader)
                weight_loader(param, loaded_weight)
                if (
                    self.config.tie_word_embeddings
                    and name == "model.embed_tokens.weight"
                    and (_is_cpu and _is_amx_available)
                ):
                    param_lm_head = params_dict["lm_head.weight"]
                    weight_loader = getattr(
                        param_lm_head, "weight_loader", default_weight_loader
                    )
                    weight_loader(param_lm_head, loaded_weight)
            loaded_params.add(name)
        if bare_backbone and self.pp_group.is_last_rank:
            self._load_decision_readout()
            loaded_params.add("lm_head.weight")
        if isinstance(self.pooler, JointSchemaPooler):
            self._load_joint_head()
            loaded_params.update(
                f"pooler.head.{name}" for name, _ in self.pooler.head.named_parameters()
            )
        return loaded_params

    def _load_joint_head(self) -> None:
        """Load joint_head.safetensors, which the checkpoint index leaves out."""
        model = get_model()
        state_dict = load_file(
            cached_file(
                model.model_path, "joint_head.safetensors", revision=model.revision
            )
        )
        self.pooler.head.load_state_dict(state_dict, strict=True)

    def _load_decision_readout(self) -> None:
        """Place the checkpoint's decision readout in the LM head rows of its codes."""
        model = get_model()
        config = load_decision_config(model.model_path, model.revision)
        if config is None:
            raise ValueError(
                "This Qwen3_5Model checkpoint has no LM head and no "
                "decision_config.json readout to serve in its place"
            )
        readout = load_file(
            cached_file(
                model.model_path, "readout.safetensors", revision=model.revision
            )
        )["weight"]
        head = readout.new_zeros(self.lm_head.org_vocab_size, readout.shape[1])
        head[config["token_ids"]] = readout
        self.lm_head.weight_loader(self.lm_head.weight, head)


class Qwen3_5MoeForConditionalGeneration(Qwen3VLForConditionalGeneration):
    """Qwen3.5 MoE Vision-Language Model."""

    packed_modules_mapping = Qwen3_5ForCausalLM.packed_modules_mapping
    hf_to_sglang_mapper = None

    supported_lora_modules = Qwen3_5ForCausalLM.supported_lora_modules

    def __init__(
        self,
        config: Qwen3_5MoeConfig,
        quant_config: Optional[QuantizationConfig] = None,
        prefix: str = "",
        language_model_cls=Qwen3_5MoeForCausalLM,
    ) -> None:
        super().__init__(config, quant_config, prefix, language_model_cls)
        rope_config = getattr(self.config, "rope_parameters", None) or getattr(
            self.config, "rope_scaling", {}
        )
        self.is_mrope_enabled = (
            not self.language_model_only and "mrope_section" in rope_config
        )

        self.deepstack_visual_indexes = (
            self.visual.deepstack_visual_indexes if self.visual is not None else []
        )

        self.num_fused_shared_experts = 0
        if _use_aiter and not _disable_shared_experts_fusion():
            self.num_fused_shared_experts = self._get_num_fused_shared_experts()

        self.enable_shared_expert_fusion = self.num_fused_shared_experts > 0

    def get_hidden_dim(self, module_name: str, layer_idx: int):
        return self.model.get_hidden_dim(module_name, layer_idx)

    def prepare_before_cuda_graph_capture(self, model_runner) -> None:
        prepare = getattr(self.model, "prepare_before_cuda_graph_capture", None)
        if prepare is not None:
            prepare(model_runner)

    def should_apply_lora(self, module_name: str) -> bool:
        # Accept all language model layer modules (attention, linear_attn, mlp).
        return module_name.startswith("model.layers.")

    def _get_num_fused_shared_experts(self):
        if not hasattr(self.model, "layers"):
            return 0
        for layer_id in range(self.model.start_layer, self.model.end_layer):
            mlp = getattr(self.model.layers[layer_id], "mlp", None)
            if hasattr(mlp, "num_fused_shared_experts"):
                return mlp.num_fused_shared_experts
        return 0

    def get_embed_and_head(self):
        embed = self.model.embed_tokens.weight if self.pp_group.is_first_rank else None
        head = self.lm_head.weight if self.pp_group.is_last_rank else None
        return embed, head

    def set_embed_and_head(self, embed, head):
        if self.pp_group.is_first_rank and embed is not None:
            del self.model.embed_tokens.weight
            self.model.embed_tokens.weight = embed
        if self.pp_group.is_last_rank and head is not None:
            del self.lm_head.weight
            self.lm_head.weight = head
        if _is_xpu:
            torch.xpu.empty_cache()
            torch.xpu.synchronize()
        else:
            torch.cuda.empty_cache()
            torch.cuda.synchronize()

    def load_weights(self, weights: Iterable[Tuple[str, torch.Tensor]]):
        weights = QWEN3_5_KV_SCALE_MAPPER.apply(weights)
        stacked_params_mapping = [
            # (param_name, shard_name, shard_id)
            ("qkv_proj", "q_proj", "q"),
            ("qkv_proj", "k_proj", "k"),
            ("qkv_proj", "v_proj", "v"),
            ("gate_up_proj", "gate_proj", 0),
            ("gate_up_proj", "up_proj", 1),
            # GDN fused projections
            ("in_proj_qkvz.", "in_proj_qkv.", (0, 1, 2)),
            ("in_proj_qkvz.", "in_proj_z.", 3),
            ("in_proj_ba.", "in_proj_b.", 0),
            ("in_proj_ba.", "in_proj_a.", 1),
        ]

        num_experts = self.config.num_experts

        # Params for weights, fp8 weight scales, fp8 activation scales
        # (param_name, weight_name, expert_id, shard_id)
        expert_params_mapping = FusedMoE.make_expert_params_mapping(
            ckpt_gate_proj_name="gate_proj",
            ckpt_down_proj_name="down_proj",
            ckpt_up_proj_name="up_proj",
            num_experts=(
                num_experts
                if not self.enable_shared_expert_fusion
                else num_experts + self.num_fused_shared_experts
            ),
        )

        # Skip loading extra parameters for GPTQ/modelopt models.
        ignore_suffixes = (
            ".bias",
            "_bias",
            ".k_scale",
            "_k_scale",
            ".v_scale",
            "_v_scale",
            "_weight_scale",
            "_input_scale",
        )

        is_fused_expert = False
        fused_expert_params_mapping = [
            ("experts.w13_weight", "experts.gate_up_proj", 0, "w1"),
            ("experts.w2_weight", "experts.down_proj", 0, "w2"),
        ]

        if self.enable_shared_expert_fusion:
            """
            When shared experts are fused, we need to map the shared experts to routed experts.

            mlp.share_expert.gate_up_proj.weight  --> experts.512.gate_up_proj.weight -> experts.w13_weight, expert_id = 512
            mlp.share_expert.down_proj.weight  --> experts.512.down_proj.weight -> experts.w2_weight, expert_id = 512
            """
            fused_expert_params_mapping += [
                (
                    "experts.w13_",
                    f"experts.{num_experts}.gate_up_proj.",
                    num_experts,
                    "w1",
                ),
                (
                    "experts.w2_",
                    f"experts.{num_experts}.down_proj.",
                    num_experts,
                    "w2",
                ),
                ## shared experts may contain gate_proj and up_proj instead of gate_up_proj
                (
                    "experts.w13_",
                    f"experts.{num_experts}.gate_proj.",
                    num_experts,
                    "w1",
                ),
                (
                    "experts.w13_",
                    f"experts.{num_experts}.up_proj.",
                    num_experts,
                    "w3",
                ),
            ]

        def load_fused_expert_weights(
            name: str,
            params_dict: dict,
            loaded_weight: torch.Tensor,
            shard_id: str,
            num_experts: int,
        ):
            if name not in params_dict:
                return False
            param = params_dict[name]
            weight_loader = param.weight_loader
            # let ep moe layer to gracefully handle expert_ids that do not belong to local moe rank
            for expert_id in range(num_experts):
                curr_expert_weight = loaded_weight[expert_id]
                weight_loader(
                    param,
                    curr_expert_weight,
                    name,
                    shard_id,
                    expert_id,
                )
            return True

        loaded_params: Set[str] = set()
        params_dict = dict(self.named_parameters(remove_duplicate=False))

        for name, loaded_weight in weights:
            if "rotary_emb.inv_freq" in name:
                continue
            if "mtp" in name:
                continue
            if "language_model" in name:
                name = name.replace(r"model.language_model.", r"model.")
            if ".self_attn." in name:
                name = name.replace(".self_attn", "")
            if (
                self.config.tie_word_embeddings
                and self.pp_group.is_last_rank
                and "model.embed_tokens.weight" in name
            ):
                if "lm_head.weight" in params_dict:
                    lm_head_param = params_dict["lm_head.weight"]
                    weight_loader = getattr(
                        lm_head_param, "weight_loader", default_weight_loader
                    )
                    weight_loader(lm_head_param, loaded_weight)

            layer_id = get_layer_id(name)
            if (
                layer_id is not None
                and hasattr(self, "start_layer")
                and (layer_id < self.start_layer or layer_id >= self.end_layer)
            ):
                continue

            if self.enable_shared_expert_fusion:
                if "mlp.shared_expert." in name:
                    # Firstly map mlp.shared_expert.xx_proj to mlp.experts.512.xx_proj
                    name = name.replace(
                        "mlp.shared_expert.",
                        f"mlp.experts.{num_experts}.",
                    )

            for param_name, weight_name, shard_id in stacked_params_mapping:
                if name.endswith("experts.gate_up_proj") or name.endswith(
                    "experts.down_proj"
                ):
                    is_fused_expert = True
                    expert_params_mapping = fused_expert_params_mapping

                # Skip non-stacked layers and experts (experts handled below).
                if weight_name not in name:
                    continue
                if "visual" in name:
                    continue

                # We have mlp.experts[0].gate_proj in the checkpoint.
                # Since we handle the experts below in expert_params_mapping,
                # we need to skip here BEFORE we update the name, otherwise
                # name will be updated to mlp.experts[0].gate_up_proj, which
                # will then be updated below in expert_params_mapping
                # for mlp.experts[0].gate_gate_up_proj, which breaks load.
                if "mlp.experts" in name:
                    continue
                name = name.replace(weight_name, param_name)
                # Skip loading extra parameters for GPTQ/modelopt models.
                if name.endswith(ignore_suffixes) and name not in params_dict:
                    continue

                if name not in params_dict:
                    continue

                param = params_dict[name]
                weight_loader = param.weight_loader
                weight_loader(param, loaded_weight, shard_id)
                break
            else:
                # Track if this is an expert weight to enable early skipping
                is_expert_weight = False

                for mapping in expert_params_mapping:
                    param_name, weight_name, expert_id, shard_id = mapping
                    if weight_name not in name:
                        continue
                    if "visual" in name or self.config.encoder_only:
                        continue
                    # Anyway, this is an expert weight and should not be
                    # attempted to load as other weights later
                    is_expert_weight = True
                    name_mapped = name.replace(weight_name, param_name)
                    if is_fused_expert:
                        # is_fused_expert is True, the checkpoint contains gate_up_proj and down_proj for each expert
                        if "experts.gate_up_proj" in name:
                            # experts.gate_up_proj contains all 512 routed experts, excluding shared experts
                            # split into w1 and w3
                            loaded_weight = loaded_weight.chunk(2, dim=-2)
                            load_fused_expert_weights(
                                name_mapped,
                                params_dict,
                                loaded_weight[0],
                                "w1",
                                num_experts,
                            )
                            load_fused_expert_weights(
                                name_mapped,
                                params_dict,
                                loaded_weight[1],
                                "w3",
                                num_experts,
                            )
                        elif "experts.down_proj" in name:
                            # experts.down_proj contains all 512 routed experts, excluding shared experts
                            load_fused_expert_weights(
                                name_mapped,
                                params_dict,
                                loaded_weight,
                                shard_id,
                                num_experts,
                            )
                        elif self.enable_shared_expert_fusion:
                            # shared experts should be loaded to experts.w13_weight and experts.w2_weight
                            param = params_dict[name_mapped]
                            weight_loader = getattr(
                                param, "weight_loader", default_weight_loader
                            )
                            param = params_dict[name_mapped]
                            if f"{num_experts}.gate_up_proj" in name:
                                # split into w1 and w3
                                loaded_weight = loaded_weight.chunk(2, dim=-2)
                                # load to experts.w13_weight, shard_id = w1, expert_id = 512
                                weight_loader(
                                    param,
                                    loaded_weight[0],
                                    name_mapped,
                                    "w1",
                                    expert_id,
                                )
                                # load to experts.w13_weight, shard_id = w3, expert_id = 512
                                weight_loader(
                                    param,
                                    loaded_weight[1],
                                    name_mapped,
                                    "w3",
                                    expert_id,
                                )
                            else:
                                # load down_proj to experts.w2_weight, shard_id = w2, expert_id = 512
                                # Or load gate_proj and up_proj to experts.w13_weight, shard_id = w1/w3, expert_id = 512
                                weight_loader(
                                    param,
                                    loaded_weight,
                                    name_mapped,
                                    shard_id,
                                    expert_id,
                                )
                    else:
                        # Skip loading extra parameters for GPTQ models.
                        if (
                            name_mapped.endswith(ignore_suffixes)
                            and name_mapped not in params_dict
                        ):
                            continue
                        param = params_dict[name_mapped]
                        # We should ask the weight loader to return success or
                        # not here since otherwise we may skip experts with
                        # # other available replicas.
                        weight_loader = param.weight_loader
                        weight_loader(
                            param,
                            loaded_weight,
                            name_mapped,
                            shard_id=shard_id,
                            expert_id=expert_id,
                        )
                    name = name_mapped
                    break
                else:
                    if is_expert_weight:
                        # This is an expert weight but not mapped to this rank, skip all remaining processing
                        continue

                    if "visual" in name:
                        # adapt to VisionAttention
                        name = name.replace(r"attn.qkv.", r"attn.qkv_proj.")
                        name = name.replace(r"model.visual.", r"visual.")

                    # Skip loading extra parameters for GPTQ/modelopt models.
                    if name.endswith(ignore_suffixes) and name not in params_dict:
                        continue

                    if name in params_dict.keys():
                        param = params_dict[name]
                        weight_loader = getattr(
                            param, "weight_loader", default_weight_loader
                        )
                        weight_loader(param, loaded_weight)
                    else:
                        logger.warning(f"Parameter {name} not found in params_dict")
            loaded_params.add(name)

        self._routed_experts_weights_of_layer = LazyValue(
            lambda: {
                layer_id: self.model.layers[layer_id].mlp.get_moe_weights()
                for layer_id in range(self.model.start_layer, self.model.end_layer)
                if isinstance(self.model.layers[layer_id].mlp, Qwen2MoeSparseMoeBlock)
            }
        )

        return loaded_params

    @property
    def routed_experts_weights_of_layer(self):
        return self._routed_experts_weights_of_layer.value

    @classmethod
    def get_model_config_for_expert_location(cls, config):
        text_config = getattr(config, "text_config", config)
        return ModelConfigForExpertLocation(
            num_layers=text_config.num_hidden_layers,
            num_logical_experts=text_config.num_experts,
            num_groups=None,
        )


def _qwen3_5_shared_experts_fusion_disable_reason(hf_config, quant_config):
    """Why this Qwen3.5 checkpoint cannot fuse its shared expert, or None.

    ROCm-only: an MXFP4 checkpoint cannot fuse, and the model still wants the
    #25885 multi-streaming path. Asked by the loader before any layer is built,
    so it resolves the text config itself -- the loader hands over whichever
    config the entry class takes.
    """
    if not _is_hip:
        return None
    text_config = getattr(hf_config, "text_config", hf_config)
    if text_config.model_type not in _QWEN3_5_MOE_TEXT_MODEL_TYPES:
        return None
    if can_fuse_shared_expert(text_config, quant_config):
        return None
    return (
        "Qwen3.5: shared-expert fusion not supported for this checkpoint "
        "(multi-streaming #25885 still applies)."
    )


# Every class the loader may instantiate for a Qwen3.5 checkpoint answers the
# fusion question the same way.
for _entry_class in (
    Qwen3_5ForCausalLM,
    Qwen3_5MoeForCausalLM,
    Qwen3_5ForConditionalGeneration,
    Qwen3_5MoeForConditionalGeneration,
):
    _entry_class.shared_experts_fusion_disable_reason = staticmethod(
        _qwen3_5_shared_experts_fusion_disable_reason
    )


EntryClass = [Qwen3_5MoeForConditionalGeneration, Qwen3_5ForConditionalGeneration]
