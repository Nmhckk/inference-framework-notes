#!/usr/bin/env bash
set -euo pipefail

name=sglang-qwen35-hzy-171-20261021
owner=$(docker inspect -f '{{index .Config.Labels "hzy.codex.owner"}}' "$name")
test "$owner" = inference-framework

docker exec "$name" bash -lc '
set -e
for round in 1 2 3; do
  python3 /paper/input/benchmark_stream.py \
    --endpoint http://127.0.0.1:18080 \
    --model qwen35-4b \
    --framework "sglang-bf16-graph-overlap-off-c16-r${round}" \
    --dataset /paper/input/prompts-in2048-num48.jsonl \
    --requests 48 --concurrency 16 --request-rate 0 \
    --max-tokens 2048 --warmup 2 \
    --output-dir "/bench/results/sglang-bf16-overlap-off-c16-r${round}"
done
' > /data/tiankuan/huzhengyu/qwen35-sglang-20261021/logs/benchmark-overlap-off.log 2>&1
